# LabDesktop v13 — C++ / Qt

## نظام مختبر التحليلات المتقدم

تم تحويل البرنامج بالكامل من Python إلى C++ باستخدام إطار عمل Qt6/Qt5.

---

## المتطلبات للبناء

| المكتبة | الإصدار | ملاحظات |
|---------|---------|--------|
| CMake | >= 3.16 | نظام البناء |
| Qt | 6.x أو 5.15+ | Core, Gui, Widgets, Sql, WebEngineWidgets, WebChannel, PrintSupport |
| C++17 | - | مترجم يدعم C++17 |

### تثبيت على Windows
1. تثبيت Qt من: https://www.qt.io/download-qt-installer
2. اختيار المكونات: Qt 6.x → Desktop → MSVC 2022 (أو MinGW)
3. تشغيل `build_windows.bat`

### تثبيت على Ubuntu/Debian
```bash
sudo apt install cmake qt6-base-dev qt6-webengine-dev libqt6sql6-sqlite 
```
ثم: `./build_linux.sh`

---

## البناء

### Windows
```
build_windows.bat
```
الناتج: `build\bin\LabDesktop.exe` + DLLs

### Linux
```bash
chmod +x build_linux.sh
./build_linux.sh
```
الناتج: `build/bin/LabDesktop`

---

## هيكل المشروع

```
LabDesktop-Qt/
├── CMakeLists.txt            # نظام البناء
├── build_windows.bat         # سكربت البناء (ويندوز)
├── build_linux.sh            # سكربت البناء (لينكس)
├── src/
│   ├── main.cpp              # نقطة الدخول
│   ├── Models.h              # النماذج (TestItem, PatientData, SheetData)
│   ├── DatabaseManager.h     # طبقة قاعدة البيانات
│   ├── DatabaseManager.cpp   # SQLite مع WAL + فهرسة
│   ├── MainWindow.h          # النافذة الرئيسية
│   ├── MainWindow.cpp        # واجهة المستخدم + المنطق
│   ├── TestSelectionDialog.h # مربع اختيار التحاليل
│   ├── TestSelectionDialog.cpp
│   ├── ReportWidget.h        # معاينة التقرير
│   ├── ReportWidget.cpp      # QWebEngineView
│   ├── HtmlReportGenerator.h # محرك التقارير
│   └── HtmlReportGenerator.cpp
└── resources/
    ├── resources.qrc         # ملف الموارد Qt
    ├── style.qss             # تنسيق الواجهة
    └── default_tests.json    # 114 تحليل افتراضي
```

---

## المميزات

-  **بدون Python**: ملف .exe مستقل، لا يحتاج أي بيئة تشغيل
-  **SQLite WAL**: قراءة وكتابة متوازية بدون تجميد
-  **114 تحليل**: دم، براز، بول، سائل منوي
-  **معاينة فورية**: التقرير يتحدث تلقائياً
-  **طباعة مباشرة**: عبر QWebEnginePage::print()
-  **حفظ تلقائي**: كل 5 ثوان
-  **استيراد/تصدير JSON**: توافق مع النسخة القديمة
-  **تصميم RTL**: دعم كامل للعربية
-  **ذاكرة ذكية**: std::unique_ptr + Parent-Child(QObject)

---

## التوزيع

بعد البناء على ويندوز:
1. `windeployqt build/bin/LabDesktop.exe` يُنسخ DLLs المطلوبة فقط
2. نسخ مجلد `build/bin` كاملاً إلى أي جهاز ويندوز
3. ملف `LabDesktopData/labdata.db` يُنشأ تلقائياً بجانب البرنامج


## v13 — Immediate SQLite Storage

- SQLite normalized tables are the authoritative persistent storage.
- Test edits (name, normal range by gender, unit, result, selection) are written immediately to the affected row.
- Patient name/date/gender and active sheet are written immediately.
- Removed the 5-second auto-save timer.
- Legacy `app_settings/full_state` is retained only for backward compatibility and one-time migration.
- Added real SQLite database backup and restore.
- Restore clears stale target rows before importing the backup.
- SQLite WAL + NORMAL synchronous mode remain enabled for smooth desktop operation.
- No full JSON serialization is performed during ordinary edits.
