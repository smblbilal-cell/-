#!/bin/bash
# ═══════════════════════════════════════════════════════
#   LabDesktop v12 - C++/Qt Build Script (Linux)
# ═══════════════════════════════════════════════════════

set -e

echo "============================================"
echo "  LabDesktop v12 - C++/Qt Build"
echo "============================================"

# Check CMake
if ! command -v cmake &> /dev/null; then
    echo "[ERROR] CMake not found! Install: sudo apt install cmake"
    exit 1
fi

# Check Qt
if [ -z "$QTDIR" ]; then
    echo "[INFO] QTDIR not set, trying to auto-detect..."
    QTDIR=$(qmake -query QT_INSTALL_PREFIX 2>/dev/null || echo "")
fi
if [ -z "$QTDIR" ] || [ ! -d "$QTDIR" ]; then
    echo "[ERROR] Qt not found! Set QTDIR or install Qt6/Qt5."
    echo "  Ubuntu: sudo apt install qt6-base-dev qt6-webengine-dev libqt6sql6-sqlite"
    echo "  Or:     sudo apt install qtbase5-dev qtwebengine5-dev libqt5sql5-sqlite"
    exit 1
fi

echo "Using Qt: $QTDIR"

# Build
mkdir -p build && cd build
cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH="$QTDIR" ..
cmake --build . --parallel $(nproc)

echo ""
echo "============================================"
echo "  Build Complete!"
echo "  Binary: build/bin/LabDesktop"
echo "============================================"
