@echo off
chcp 65001 >nul 2>&1
setlocal enabledelayedexpansion

echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║   LabDesktop v12 - C++/Qt Windows Build      ║
echo  ╚══════════════════════════════════════════════╝
echo.

:: ═════════════════════════════════════════════════════════
::  Step 0: Check prerequisites
:: ═════════════════════════════════════════════════════════

where cmake >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] CMake not found!
    echo.
    echo   Download from: https://cmake.org/download/
    echo   Or install via: winget install Kitware.CMake
    echo.
    pause
    exit /b 1
)

:: ── Detect Qt installation ───────────────────────────
set "QT_PATH="
set "QT_MAJOR=6"

:: Method 1: CMAKE_PREFIX_PATH environment variable
if defined CMAKE_PREFIX_PATH (
    set "QT_PATH=!CMAKE_PREFIX_PATH!"
    echo [INFO] Using CMAKE_PREFIX_PATH: !QT_PATH!
)

:: Method 2: Qt6 default installation paths
if "%QT_PATH%"=="" (
    for %%p in (
        "C:\Qt\6.8.0\msvc2022_64"
        "C:\Qt\6.7.3\msvc2022_64"
        "C:\Qt\6.7.2\msvc2022_64"
        "C:\Qt\6.7.1\msvc2022_64"
        "C:\Qt\6.7.0\msvc2022_64"
        "C:\Qt\6.6.3\msvc2022_64"
        "C:\Qt\6.5.3\msvc2022_64"
        "C:\Qt\6.8.0\mingw_64"
        "C:\Qt\6.7.3\mingw_64"
    ) do (
        if exist %%~p\bin\qmake.exe (
            set "QT_PATH=%%~p"
            echo [INFO] Found Qt at: !QT_PATH!
            goto :qt_found
        )
    )
)

:: Method 3: Qt5 fallback paths
if "%QT_PATH%"=="" (
    for %%p in (
        "C:\Qt\5.15.2\msvc2019_64"
        "C:\Qt\5.15.14\msvc2019_64"
        "C:\Qt\5.15.2\mingw81_64"
    ) do (
        if exist %%~p\bin\qmake.exe (
            set "QT_PATH=%%~p"
            set "QT_MAJOR=5"
            echo [INFO] Found Qt5 at: !QT_PATH!
            goto :qt_found
        )
    )
)

:qt_found
if "%QT_PATH%"=="" (
    echo [ERROR] Qt not found!
    echo.
    echo   Install Qt from: https://www.qt.io/download-qt-installer
    echo   Or set environment variable:
    echo     set CMAKE_PREFIX_PATH=C:\Qt\6.8.0\msvc2022_64
    echo.
    echo   During Qt installation, make sure to select:
    echo     - Desktop Qt 6.x  MSVC 2022 64-bit
    echo     - Qt WebEngine module
    echo     - Qt Print Support module
    echo.
    pause
    exit /b 1
)

:: ── Detect compiler ────────────────────────────────────
set "CMAKE_GEN="
set "BUILD_CONFIG=Release"

:: Check for MSVC (cl.exe)
where cl >nul 2>&1
if %errorlevel% equ 0 (
    echo [INFO] MSVC compiler detected
    for /f "tokens=4 delims= " %%v in ('cl 2^>^&1 ^| findstr /C:"Version"') do (
        echo [INFO] Compiler version: %%v
    )
    set "CMAKE_GEN=Ninja"
) else (
    :: Check for MinGW (g++.exe)
    where g++ >nul 2>&1
    if %errorlevel% equ 0 (
        echo [INFO] MinGW compiler detected
        set "CMAKE_GEN=Ninja"
    ) else (
        :: No compiler in PATH - try VS Developer Command Prompt setup
        echo [INFO] No compiler in PATH. Checking Visual Studio...

        :: Try VS 2022
        if exist "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" (
            echo [INFO] Found VS 2022 Community
            call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -arch=amd64 >nul 2>&1
            set "CMAKE_GEN=Ninja"
            goto :compiler_found
        )
        if exist "C:\Program Files\Microsoft Visual Studio\2022\Professional\Common7\Tools\VsDevCmd.bat" (
            echo [INFO] Found VS 2022 Professional
            call "C:\Program Files\Microsoft Visual Studio\2022\Professional\Common7\Tools\VsDevCmd.bat" -arch=amd64 >nul 2>&1
            set "CMAKE_GEN=Ninja"
            goto :compiler_found
        )
        if exist "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\Common7\Tools\VsDevCmd.bat" (
            echo [INFO] Found VS 2022 Enterprise
            call "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\Common7\Tools\VsDevCmd.bat" -arch=amd64 >nul 2>&1
            set "CMAKE_GEN=Ninja"
            goto :compiler_found
        )
        :: Try VS 2019
        if exist "C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\Common7\Tools\VsDevCmd.bat" (
            echo [INFO] Found VS 2019 Community
            call "C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\Common7\Tools\VsDevCmd.bat" -arch=amd64 >nul 2>&1
            set "CMAKE_GEN=Ninja"
            goto :compiler_found
        )

        echo [ERROR] No C++ compiler found!
        echo.
        echo   Option 1: Install Visual Studio 2022 Community (free)
        echo             https://visualstudio.microsoft.com/vs/community/
        echo             Select: Desktop development with C++
        echo.
        echo   Option 2: Install MinGW-w64
        echo             https://www.mingw-w64.org/
        echo.
        echo   Option 3: Open "x64 Native Tools Command Prompt for VS 2022"
        echo             then run this script again.
        echo.
        pause
        exit /b 1
    )
)

:compiler_found

:: ═════════════════════════════════════════════════════════
::  Step 1: CMake Configure
:: ═════════════════════════════════════════════════════════

if not exist build mkdir build
cd build

echo.
echo [1/3] Configuring with CMake...
echo        Qt Path: %QT_PATH%
echo        Generator: %CMAKE_GEN%
echo.

cmake -G "%CMAKE_GEN%" ^
    -DCMAKE_BUILD_TYPE=Release ^
    -DCMAKE_PREFIX_PATH="%QT_PATH%" ^
    ..

if %errorlevel% neq 0 (
    echo.
    echo [WARN] Ninja failed, trying Visual Studio generator...
    echo.
    cmake -G "Visual Studio 17 2022" -A x64 ^
        -DCMAKE_BUILD_TYPE=Release ^
        -DCMAKE_PREFIX_PATH="%QT_PATH%" ^
        ..
)

if %errorlevel% neq 0 (
    echo [WARN] VS 2022 failed, trying VS 2019...
    echo.
    cmake -G "Visual Studio 16 2019" -A x64 ^
        -DCMAKE_BUILD_TYPE=Release ^
        -DCMAKE_PREFIX_PATH="%QT_PATH%" ^
        ..
)

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] CMake configuration FAILED!
    echo.
    echo   Possible causes:
    echo   - Qt WebEngine module not installed
    echo   - Wrong Qt version (need MSVC 64-bit, not MinGW, for WebEngine)
    echo   - CMAKE_PREFIX_PATH points to wrong directory
    echo.
    pause
    exit /b 1
)

:: ═════════════════════════════════════════════════════════
::  Step 2: Build
:: ═════════════════════════════════════════════════════════

echo.
echo [2/3] Building (Release mode)...
echo.

cmake --build . --config Release --parallel

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Build FAILED!
    echo.
    echo   Check the error messages above for details.
    echo   Common issues:
    echo   - Missing Qt modules (run Qt Maintenance Tool to add WebEngine)
    echo   - Compiler version mismatch
    echo.
    pause
    exit /b 1
)

:: ═════════════════════════════════════════════════════════
::  Step 3: Deploy Qt DLLs
:: ═════════════════════════════════════════════════════════

echo.
echo [3/3] Deploying Qt dependencies with windeployqt...
echo.

set "EXE_PATH="
for /r "bin" %%f in (LabDesktop.exe) do set "EXE_PATH=%%f"

if "%EXE_PATH%"=="" (
    echo [WARN] LabDesktop.exe not found in bin\ directory
    echo [INFO] Skipping windeployqt (run it manually if needed)
    goto :done
)

:: Run windeployqt from the detected Qt bin
set "QT_BIN=%QT_PATH%\bin"
if exist "%QT_BIN%\windeployqt.exe" (
    "%QT_BIN%\windeployqt.exe" --release --no-translations "%EXE_PATH%"
    if %errorlevel% equ 0 (
        echo [OK] Dependencies deployed successfully
    ) else (
        echo [WARN] windeployqt had issues - app may still work
    )
) else (
    echo [WARN] windeployqt not found at %QT_BIN%
    echo [INFO] Try running: windeployqt --release "%EXE_PATH%"
)

:done
echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║          BUILD SUCCESSFUL!                    ║
echo  ╠══════════════════════════════════════════════╣
echo  ║                                              ║
echo  ║  Output: build\bin\LabDesktop.exe            ║
echo  ║                                              ║
echo  ║  To distribute: copy the entire            ║
echo  ║  'build\bin' folder to any Windows PC.     ║
echo  ║  No Python, no Qt installation needed.    ║
echo  ║                                              ║
echo  ╚══════════════════════════════════════════════╝
echo.
pause