// ═══════════════════════════════════════════════════════
//  LabDesktop v12 — C++ / Qt
//  Main Entry Point
// ═══════════════════════════════════════════════════════

#include <QApplication>
#include <QTranslator>
#include <QLocale>
#include <QFont>
#include <QDebug>

#include "MainWindow.h"

int main(int argc, char *argv[])
{
    // High-DPI: Qt6 enables this by default; Qt5 needs explicit opt-in
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QApplication::setAttribute(Qt::AA_UseHighDpiPixmaps);
#endif

    QApplication app(argc, argv);
    app.setApplicationName(QStringLiteral("LabDesktop"));
    app.setApplicationVersion(QStringLiteral("12.0.0"));
    app.setOrganizationName(QStringLiteral("LabSystems"));

    // ── Font setup for Arabic ──────────────────────
    QFont appFont(QStringLiteral("Segoe UI"), 9);
    app.setFont(appFont);

    // ── Main Window ────────────────────────────────
    Lab::MainWindow window;
    window.show();

    return app.exec();
}
