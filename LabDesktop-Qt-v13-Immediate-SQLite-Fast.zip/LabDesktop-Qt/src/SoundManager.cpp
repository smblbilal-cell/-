#include "SoundManager.h"

#include <QSoundEffect>
#include <QUrl>
#include <QDebug>

namespace Lab {

// ═══════════════════════════════════════════════════════
//  Constructor — load all sounds from embedded .qrc
// ═══════════════════════════════════════════════════════

SoundManager::SoundManager(QObject *parent)
    : QObject(parent)
    , m_typeClick(new QSoundEffect(this))
    , m_langChange(new QSoundEffect(this))
    , m_btnClick(new QSoundEffect(this))
    , m_warning(new QSoundEffect(this))
{
    // Load sounds from Qt resource system (embedded in .exe)
    m_typeClick->setSource(QUrl(QStringLiteral("qrc:/sounds/type_click.wav")));
    m_langChange->setSource(QUrl(QStringLiteral("qrc:/sounds/lang_change.wav")));
    m_btnClick->setSource(QUrl(QStringLiteral("qrc:/sounds/btn_click.wav")));
    m_warning->setSource(QUrl(QStringLiteral("qrc:/sounds/warning.wav")));

    // Pre-load into memory (avoid first-play delay)
    m_typeClick->load();
    m_langChange->load();
    m_btnClick->load();
    m_warning->load();

    // Apply initial volume
    for (auto *sfx : {m_typeClick, m_langChange, m_btnClick, m_warning}) {
        sfx->setVolume(m_volume);
    }

    qDebug() << "[Sound] Audio system initialized";
}

// ═══════════════════════════════════════════════════════
//  Play
// ═══════════════════════════════════════════════════════

void SoundManager::play(SoundType type)
{
    if (!m_enabled || m_muted) return;

    QSoundEffect *sfx = nullptr;
    switch (type) {
    case TypeClick:    sfx = m_typeClick;    break;
    case LangChange:   sfx = m_langChange;   break;
    case ButtonClick:  sfx = m_btnClick;     break;
    case WarningAlert: sfx = m_warning;      break;
    }

    if (sfx && sfx->isLoaded()) {
        sfx->play();
    }

    if (type == WarningAlert) {
        emit warningTriggered();
    }
}

// ═══════════════════════════════════════════════════════
//  Volume
// ═══════════════════════════════════════════════════════

void SoundManager::setVolume(qreal volume)
{
    m_volume = qBound(0.0, volume, 1.0);
    for (auto *sfx : {m_typeClick, m_langChange, m_btnClick, m_warning}) {
        if (sfx) sfx->setVolume(m_volume);
    }
    emit volumeChanged(m_volume);
}

// ═══════════════════════════════════════════════════════
//  Mute
// ═══════════════════════════════════════════════════════

void SoundManager::setMuted(bool muted)
{
    if (m_muted == muted) return;
    m_muted = muted;
    for (auto *sfx : {m_typeClick, m_langChange, m_btnClick, m_warning}) {
        if (sfx) sfx->setVolume(m_muted ? 0.0 : m_volume);
    }
    emit mutedChanged(m_muted);
}

// ═══════════════════════════════════════════════════════
//  Enable / Disable
// ═══════════════════════════════════════════════════════

void SoundManager::setEnabled(bool enabled)
{
    m_enabled = enabled;
}

} // namespace Lab
