#pragma once

#include <QString>
#include <QDate>
#include <QJsonObject>
#include <QJsonArray>
#include <QVector>
#include <QMap>
#include <QSet>
#include <QDebug>

namespace Lab {

// ═══════════════════════════════════════════════════════
//  Enums
// ═══════════════════════════════════════════════════════

enum class SheetType {
    Blood = 0,
    Stool = 1,
    Urine = 2,
    Semen = 3
};

enum class Gender {
    Male = 0,
    Female = 1,
    Child = 2
};

enum class QualType {
    Quantitative = 0,
    Dropdown = 1,
    SimpleQualitative = 2,
    Qualitative = 3,
    IgG_IgM = 4
};

// ═══════════════════════════════════════════════════════
//  Utility: enum ↔ string conversions
// ═══════════════════════════════════════════════════════

inline QString sheetTypeKey(SheetType t) {
    switch (t) {
    case SheetType::Blood:  return QStringLiteral("blood");
    case SheetType::Stool:  return QStringLiteral("stool");
    case SheetType::Urine:  return QStringLiteral("urine");
    case SheetType::Semen:  return QStringLiteral("semen");
    }
    return {};
}

inline QString sheetTypeLabel(SheetType t) {
    switch (t) {
    case SheetType::Blood:  return QStringLiteral("Blood");
    case SheetType::Stool:  return QStringLiteral("Stool");
    case SheetType::Urine:  return QStringLiteral("Urine");
    case SheetType::Semen:  return QStringLiteral("Semen");
    }
    return {};
}

inline QString sheetTypeTitle(SheetType t) {
    switch (t) {
    case SheetType::Blood:  return {};
    case SheetType::Stool:  return QStringLiteral("G.S.E (General Stool Examination)");
    case SheetType::Urine:  return QStringLiteral("G.U.E (General Urine Examination)");
    case SheetType::Semen:  return QStringLiteral("Seminal Fluid Analysis");
    }
    return {};
}

inline QString sheetTypeColor(SheetType t) {
    switch (t) {
    case SheetType::Blood:  return QStringLiteral("#e74c3c");
    case SheetType::Stool:  return QStringLiteral("#8B4513");
    case SheetType::Urine:  return QStringLiteral("#f39c12");
    case SheetType::Semen:  return QStringLiteral("#9b59b6");
    }
    return {};
}

inline SheetType sheetTypeFromKey(const QString &key) {
    if (key == QLatin1String("blood")) return SheetType::Blood;
    if (key == QLatin1String("stool")) return SheetType::Stool;
    if (key == QLatin1String("urine")) return SheetType::Urine;
    if (key == QLatin1String("semen")) return SheetType::Semen;
    return SheetType::Blood;
}

inline QString genderKey(Gender g) {
    switch (g) {
    case Gender::Male:   return QStringLiteral("Male");
    case Gender::Female: return QStringLiteral("Female");
    case Gender::Child:  return QStringLiteral("Child");
    }
    return {};
}

inline Gender genderFromKey(const QString &key) {
    if (key == QLatin1String("Female")) return Gender::Female;
    if (key == QLatin1String("Child"))  return Gender::Child;
    return Gender::Male;
}

inline QString qualTypeKey(QualType q) {
    switch (q) {
    case QualType::Quantitative:       return QStringLiteral("Quantitative");
    case QualType::Dropdown:           return QStringLiteral("Dropdown");
    case QualType::SimpleQualitative:  return QStringLiteral("SimpleQualitative");
    case QualType::Qualitative:        return QStringLiteral("Qualitative");
    case QualType::IgG_IgM:            return QStringLiteral("IgG_IgM");
    }
    return {};
}

inline QualType qualTypeFromKey(const QString &key) {
    if (key == QLatin1String("Dropdown"))          return QualType::Dropdown;
    if (key == QLatin1String("SimpleQualitative")) return QualType::SimpleQualitative;
    if (key == QLatin1String("Qualitative"))       return QualType::Qualitative;
    if (key == QLatin1String("IgG_IgM"))           return QualType::IgG_IgM;
    return QualType::Quantitative;
}

inline bool isFixedSheet(SheetType t) {
    return t != SheetType::Blood;
}

// ═══════════════════════════════════════════════════════
//  TestItem — single test definition
// ═══════════════════════════════════════════════════════

struct TestItem {
    int     id = 0;
    QString name;
    QString category;
    QString normalMale;
    QString normalFemale;
    QString normalChild;
    QString unit;
    bool    checked = false;
    QString result;
    QualType qualitativeType = QualType::Quantitative;
    QString dropdownOptions;
    // IgG/IgM specific
    QString normalIgg;
    QString normalIgm;
    QString resultIgg;
    QString resultIgm;

    // --- Serialization ---
    QJsonObject toJson() const {
        QJsonObject obj;
        obj[QStringLiteral("id")]              = id;
        obj[QStringLiteral("name")]            = name;
        obj[QStringLiteral("category")]        = category;
        obj[QStringLiteral("normal_male")]     = normalMale;
        obj[QStringLiteral("normal_female")]   = normalFemale;
        obj[QStringLiteral("normal_child")]    = normalChild;
        obj[QStringLiteral("unit")]            = unit;
        obj[QStringLiteral("checked")]         = checked;
        obj[QStringLiteral("result")]          = result;
        obj[QStringLiteral("qualitative_type")] = qualTypeKey(qualitativeType);
        obj[QStringLiteral("dropdown_options")] = dropdownOptions;
        if (qualitativeType == QualType::IgG_IgM) {
            obj[QStringLiteral("normal_igg")]  = normalIgg;
            obj[QStringLiteral("normal_igm")]  = normalIgm;
            obj[QStringLiteral("result_igg")]  = resultIgg;
            obj[QStringLiteral("result_igm")]  = resultIgm;
        }
        return obj;
    }

    static TestItem fromJson(const QJsonObject &obj) {
        TestItem t;
        t.id              = obj[QStringLiteral("id")].toInt();
        t.name            = obj[QStringLiteral("name")].toString();
        t.category        = obj[QStringLiteral("category")].toString();
        t.normalMale      = obj[QStringLiteral("normal_male")].toString();
        t.normalFemale    = obj[QStringLiteral("normal_female")].toString();
        t.normalChild     = obj[QStringLiteral("normal_child")].toString();
        t.unit            = obj[QStringLiteral("unit")].toString();
        t.checked         = obj[QStringLiteral("checked")].toBool();
        t.result          = obj[QStringLiteral("result")].toString();
        t.qualitativeType = qualTypeFromKey(obj[QStringLiteral("qualitative_type")].toString());
        t.dropdownOptions = obj[QStringLiteral("dropdown_options")].toString();
        if (t.qualitativeType == QualType::IgG_IgM) {
            t.normalIgg = obj[QStringLiteral("normal_igg")]  .toString();
            t.normalIgm = obj[QStringLiteral("normal_igm")]  .toString();
            t.resultIgg = obj[QStringLiteral("result_igg")]  .toString();
            t.resultIgm = obj[QStringLiteral("result_igm")]  .toString();
        }
        return t;
    }

    // Get the normal value based on patient gender
    QString normalValue(Gender g) const {
        switch (g) {
        case Gender::Female: return normalFemale;
        case Gender::Child:  return normalChild;
        default:             return normalMale;
        }
    }

    // Get dropdown options as a string list
    QStringList dropdownList() const {
        if (dropdownOptions.isEmpty()) return {};
        return dropdownOptions.split(QLatin1Char(','));
    }
};

// ═══════════════════════════════════════════════════════
//  DropdownTemplate — reusable template for quick add
// ═══════════════════════════════════════════════════════

struct DropdownTemplate {
    QString name;
    QString options;
};

// ═══════════════════════════════════════════════════════
//  PatientData
// ═══════════════════════════════════════════════════════

struct PatientData {
    QString name;
    QDate   date = QDate::currentDate();
    Gender  gender = Gender::Male;

    QJsonObject toJson() const {
        QJsonObject obj;
        obj[QStringLiteral("patientName")]   = name;
        obj[QStringLiteral("patientDate")]   = date.toString(Qt::ISODate);
        obj[QStringLiteral("patientGender")] = genderKey(gender);
        return obj;
    }

    static PatientData fromJson(const QJsonObject &obj) {
        PatientData p;
        p.name   = obj[QStringLiteral("patientName")].toString();
        p.date   = QDate::fromString(obj[QStringLiteral("patientDate")].toString(), Qt::ISODate);
        p.gender = genderFromKey(obj[QStringLiteral("patientGender")].toString());
        return p;
    }
};

// ═══════════════════════════════════════════════════════
//  SheetData — one sheet (blood/stool/urine/semen)
// ═══════════════════════════════════════════════════════

struct SheetData {
    QVector<TestItem> tests;

    QJsonArray toJson() const {
        QJsonArray arr;
        for (const auto &t : tests) arr.append(t.toJson());
        return arr;
    }

    static SheetData fromJson(const QJsonArray &arr) {
        SheetData sd;
        sd.tests.reserve(arr.size());
        for (const auto &val : arr)
            sd.tests.append(TestItem::fromJson(val.toObject()));
        return sd;
    }

    // Get unique categories in this sheet
    QStringList categories() const {
        QSet<QString> cats;
        for (const auto &t : tests)
            if (!t.category.isEmpty()) cats.insert(t.category);
        return cats.values();
    }

    // Get tests filtered by category
    QVector<TestItem> testsByCategory(const QString &cat) const {
        QVector<TestItem> out;
        for (const auto &t : tests)
            if (t.category == cat) out.append(t);
        return out;
    }

    // Get only checked tests
    QVector<TestItem> checkedTests() const {
        QVector<TestItem> out;
        for (const auto &t : tests)
            if (t.checked) out.append(t);
        return out;
    }

    int nextAvailableId(int startFrom) const {
        QSet<int> used;
        for (const auto &t : tests) used.insert(t.id);
        int id = startFrom;
        while (used.contains(id)) ++id;
        return id;
    }
};

// ═══════════════════════════════════════════════════════
//  AllSheetsData — complete application data
// ═══════════════════════════════════════════════════════

struct AllSheetsData {
    PatientData          patient;
    SheetType            currentSheet = SheetType::Blood;
    QMap<SheetType, SheetData> sheets;
    int                  nextTestId = 423;

    SheetData &currentSheetData() { return sheets[currentSheet]; }
    const SheetData &currentSheetData() const { return sheets[currentSheet]; }

    QJsonObject toJson() const {
        QJsonObject root;
        root[QStringLiteral("patientName")]   = patient.name;
        root[QStringLiteral("patientDate")]   = patient.date.toString(Qt::ISODate);
        root[QStringLiteral("patientGender")] = genderKey(patient.gender);
        root[QStringLiteral("currentSheetType")] = sheetTypeKey(currentSheet);

        QJsonObject sheetsObj;
        const auto keys = {SheetType::Blood, SheetType::Stool, SheetType::Urine, SheetType::Semen};
        for (auto k : keys)
            sheetsObj[sheetTypeKey(k)] = sheets[k].toJson();
        root[QStringLiteral("allSheetsData")] = sheetsObj;
        root[QStringLiteral("nextTestId")] = nextTestId;
        return root;
    }

    static AllSheetsData fromJson(const QJsonObject &root) {
        AllSheetsData d;
        d.patient.name   = root[QStringLiteral("patientName")].toString();
        d.patient.date   = QDate::fromString(root[QStringLiteral("patientDate")].toString(), Qt::ISODate);
        d.patient.gender = genderFromKey(root[QStringLiteral("patientGender")].toString());
        d.currentSheet   = sheetTypeFromKey(root[QStringLiteral("currentSheetType")].toString());
        d.nextTestId     = root[QStringLiteral("nextTestId")].toInt(423);

        QJsonObject sheetsObj = root[QStringLiteral("allSheetsData")].toObject();
        const auto keys = {SheetType::Blood, SheetType::Stool, SheetType::Urine, SheetType::Semen};
        for (auto k : keys) {
            QString key = sheetTypeKey(k);
            if (sheetsObj.contains(key))
                d.sheets[k] = SheetData::fromJson(sheetsObj[key].toArray());
        }
        return d;
    }
};

// ═══════════════════════════════════════════════════════
//  Category Color Helper — shared across UI components
// ═══════════════════════════════════════════════════════

inline QString getCategoryColor(const QString &category)
{
    static const QMap<QString, QString> s_categoryColors = {
        {QStringLiteral("Biochemistry"),      QStringLiteral("#2980b9")},
        {QStringLiteral("Hematology"),        QStringLiteral("#c0392b")},
        {QStringLiteral("Hormone Analysis"),  QStringLiteral("#8e44ad")},
        {QStringLiteral("Lipid Profile"),     QStringLiteral("#27ae60")},
        {QStringLiteral("Liver Function"),    QStringLiteral("#d35400")},
        {QStringLiteral("Pancreas"),          QStringLiteral("#16a085")},
        {QStringLiteral("RFT"),               QStringLiteral("#f39c12")},
        {QStringLiteral("Serology"),          QStringLiteral("#e74c3c")},
        {QStringLiteral("VITAMINS"),          QStringLiteral("#2ecc71")},
        {QStringLiteral("lmmunology test"),   QStringLiteral("#9b59b6")},
        {QStringLiteral("Physical Examination"),   QStringLiteral("#34495e")},
        {QStringLiteral("Microscopic Examination"), QStringLiteral("#7f8c8d")},
        {QStringLiteral("Chemical Examination"),   QStringLiteral("#e67e22")},
        {QStringLiteral("Pathology"),              QStringLiteral("#c0392b")},
    };
    return s_categoryColors.value(category, QStringLiteral("#555"));
}

} // namespace Lab
