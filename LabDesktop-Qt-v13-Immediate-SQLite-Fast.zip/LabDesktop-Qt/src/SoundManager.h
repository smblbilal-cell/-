#pragma once

#include <QObject>

class QSoundEffect;

namespace Lab {

// ═══════════════════════════════════════════════════════
//  Sound Manager — centralized audio feedback system
//  All sounds are embedded in .qrc (portable, no external files)
// ═══════════════════════════════════════════════════════

class SoundManager : public QObject {
    Q_OBJECT

public:
    enum SoundType {
        TypeClick    = 0,  // Keyboard typing in text fields
        LangChange   = 1,  // Keyboard layout switched to English
        ButtonClick  = 2,  // UI button pressed
        WarningAlert = 3   // Empty result / validation failure
    };
    Q_ENUM(SoundType)

    explicit SoundManager(QObject *parent = nullptr);

    // ── Playback ────────────────────────────────────
    void play(SoundType type);

    // ── Volume control (0.0 – 1.0) ──────────────────
    void setVolume(qreal volume);
    qreal volume() const { return m_volume; }

    // ── Mute toggle ─────────────────────────────────
    void setMuted(bool muted);
    bool isMuted() const { return m_muted; }
    void toggleMute() { setMuted(!m_muted); }

    // ── Enable/disable all sounds ───────────────────
    void setEnabled(bool enabled);
    bool isEnabled() const { return m_enabled; }

signals:
    void volumeChanged(qreal volume);
    void mutedChanged(bool muted);
    void warningTriggered();

private:
    QSoundEffect *m_typeClick    = nullptr;
    QSoundEffect *m_langChange   = nullptr;
    QSoundEffect *m_btnClick    = nullptr;
    QSoundEffect *m_warning     = nullptr;

    qreal m_volume  = 0.5;
    bool  m_muted   = false;
    bool  m_enabled = true;
};

} // namespace Lab
