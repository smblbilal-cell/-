#pragma once

#include "Models.h"
#include "DatabaseManager.h"
#include "SoundManager.h"

#include <QMainWindow>
#include <QLineEdit>
#include <QDateEdit>
#include <QComboBox>
#include <QTabWidget>
#include <QTableWidget>
#include <QPushButton>
#include <QLabel>
#include <QTimer>
#include <QMenuBar>
#include <QStatusBar>
#include <QSlider>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QSplitter>

namespace Lab {

class ReportWidget;
class TestSelectionDialog;

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

protected:
    bool eventFilter(QObject *watched, QEvent *event) override;
    void closeEvent(QCloseEvent *event) override;

private slots:
    // ── Sheet switching ───────────────────────────
    void onSheetChanged(int index);

    // ── Patient fields ────────────────────────────
    void onPatientNameChanged(const QString &text);
    void onPatientDateChanged(const QDate &date);
    void onPatientGenderChanged(int index);

    // ── Actions ───────────────────────────────────
    void onNewPatient();
    void onSelectTests();
    void onSaveState();
    void onExportJson();
    void onImportJson();
    void onBackupSqlite();
    void onRestoreSqlite();
    void onPrintReport();
    void onRefreshReport();

    // ── Sound controls ────────────────────────────
    void onVolumeChanged(int value);
    void onToggleMute();
    void onToggleSounds();

private:
    // ── Build UI ──────────────────────────────────
    void setupUI();
    void setupMenuBar();
    void setupToolbar();
    void setupPatientPanel();
    void setupSheetTabs();
    void setupTestTable();
    void setupReportPanel();
    void setupSoundControls();
    void applyStyle();

    // ── Test table ────────────────────────────────
    void populateTestTable();
    void onTestCellChanged(int row, int col);
    void updateReportPreview();

    // ── Print validation ──────────────────────────
    bool validateBeforePrint();

    // ── Helpers ───────────────────────────────────
    void loadDefaultTests();
    void switchSheet(SheetType type);
    void setAllTestsChecked(bool checked);
    void showStatusBarMessage(const QString &msg, int ms = 3000);

    // ── Data ──────────────────────────────────────
    AllSheetsData       m_data;
    DatabaseManager    *m_db = nullptr;
    SoundManager       *m_sound = nullptr;

    // ── UI Elements ───────────────────────────────
    QLineEdit       *m_patientNameEdit = nullptr;
    QDateEdit       *m_patientDateEdit = nullptr;
    QComboBox       *m_patientGenderCombo = nullptr;

    QTabWidget      *m_sheetTabs = nullptr;
    QTableWidget    *m_testTable = nullptr;

    ReportWidget    *m_reportWidget = nullptr;
    QSplitter       *m_mainSplitter = nullptr;

    QPushButton     *m_btnNewPatient = nullptr;
    QPushButton     *m_btnSelectTests = nullptr;
    QPushButton     *m_btnSave = nullptr;
    QPushButton     *m_btnPrint = nullptr;

    QLabel          *m_statusLabel = nullptr;
    QSlider         *m_volumeSlider = nullptr;
    QPushButton     *m_btnMute = nullptr;

    // ── Sound state tracking ─────────────────────
    qint64          m_lastTypeSoundMs = 0;  // Debounce typing sound (ms)
};

} // namespace Lab
