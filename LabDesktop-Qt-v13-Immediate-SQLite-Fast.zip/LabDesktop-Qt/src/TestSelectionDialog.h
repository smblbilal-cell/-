#pragma once

#include "Models.h"

#include <QDialog>
#include <QTreeWidget>
#include <QLineEdit>
#include <QDialogButtonBox>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>

namespace Lab {

class TestSelectionDialog : public QDialog {
    Q_OBJECT

public:
    explicit TestSelectionDialog(AllSheetsData &data, QWidget *parent = nullptr);

private slots:
    void onCategoryClicked(QTreeWidgetItem *item, int column);
    void onSelectAll();
    void onDeselectAll();
    void onFilterChanged(const QString &text);

private:
    void buildTree();
    void populateForCategory(const QString &category);
    void populateAll();

    AllSheetsData &m_data;
    QTreeWidget    *m_tree = nullptr;
    QLineEdit      *m_filterEdit = nullptr;
    QPushButton    *m_btnSelectAll = nullptr;
    QPushButton    *m_btnDeselectAll = nullptr;
    QString         m_currentFilter;
};

} // namespace Lab