#include "ReportWidget.h"

#include <QWebEngineView>
#include <QWebEnginePage>
#include <QPrinter>
#include <QPageLayout>
#include <QVBoxLayout>
#include <QPixmap>

namespace Lab {

ReportWidget::ReportWidget(QWidget *parent)
    : QWidget(parent)
{
    auto *layout = new QVBoxLayout(this);
    layout->setContentsMargins(0, 0, 0, 0);

    m_webView = new QWebEngineView(this);
    m_webView->setContextMenuPolicy(Qt::NoContextMenu);
    layout->addWidget(m_webView);

    // Show placeholder
    m_webView->setHtml(QStringLiteral(R"(
        <html dir="rtl"><head><style>
        body { font-family: 'Segoe UI', Tahoma, Arial, sans-serif; display: flex;
               justify-content: center; align-items: center; height: 100vh; margin: 0;
               background: #f0f0f0; color: #999; }
        .placeholder { text-align: center; }
        .placeholder h2 { font-size: 24px; margin-bottom: 8px; }
        </style></head>
        <body><div class="placeholder">
            <h2>معاينة التقرير</h2>
            <p>سيظهر التقرير هنا بعد إدخال بيانات المريض واختيار التحاليل</p>
        </div></body></html>
    )"));
}

void ReportWidget::setHtml(const QString &html)
{
    if (!m_webView) return; // Null guard
    m_webView->setHtml(html);
}

void ReportWidget::print(QPrinter *printer)
{
    // CRITICAL: Both m_webView and its page() must be non-null
    // QWebEnginePage::print() uses async callback — no return value to check
    if (!printer || !m_webView) {
        qWarning() << "[Report] print(): null printer or webView";
        return;
    }

    QWebEnginePage *page = m_webView->page();
    if (!page) {
        qWarning() << "[Report] print(): QWebEnginePage is null (not yet loaded?)";
        return;
    }

    page->print(printer, [](bool ok) {
        if (ok) {
            qDebug() << "[Report] Print completed successfully";
        } else {
            qWarning() << "[Report] Print failed or was cancelled";
        }
    });
}

QPixmap ReportWidget::captureReport()
{
    if (!m_webView) return {};
    QPixmap pix(size());
    if (pix.isNull()) return {};
    render(&pix);
    return pix;
}

} // namespace Lab