#pragma once

#include "Models.h"

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QMutex>
#include <QMutexLocker>
#include <QString>
#include <QJsonObject>
#include <QJsonDocument>
#include <QDir>
#include <QStandardPaths>
#include <QDebug>
#include <QThread>

namespace Lab {

class DatabaseManager : public QObject {
    Q_OBJECT

public:
    explicit DatabaseManager(QObject *parent = nullptr);
    ~DatabaseManager() override;

    // ── Full state save/load ──────────────────────────
    void saveFullState(const AllSheetsData &data);
    AllSheetsData loadFullState();

    // Immediate, granular persistence. Each mutation writes only the affected row.
    bool saveTest(SheetType sheet, const TestItem &test);
    bool savePatient(const PatientData &patient, SheetType currentSheet, int nextTestId = 423);
    bool saveSheetChecks(SheetType sheet, const QVector<TestItem> &tests);
    bool replaceAllTests(const AllSheetsData &data);
    bool backupDatabase(const QString &filePath);
    bool restoreDatabase(const QString &filePath);

    // ── Key-value helpers (for settings/design) ───────
    void setValue(const QString &key, const QString &value);
    QString value(const QString &key, const QString &defaultValue = {}) const;

    // ── Import/Export ─────────────────────────────────
    bool exportToJsonFile(const QString &filePath, const AllSheetsData &data);
    AllSheetsData importFromJsonFile(const QString &filePath);

    // ── Archive operations ────────────────────────────
    bool archiveCurrentState(const AllSheetsData &data);

    // ── Info ──────────────────────────────────────────
    QString databasePath() const { return m_dbPath; }
    QString dataDir() const { return QFileInfo(m_dbPath).absolutePath(); }
    bool isReady() const { return m_db.isOpen() && m_initialized; }

signals:
    void stateSaved();
    void stateLoaded(const AllSheetsData &data);
    void error(const QString &message);

private:
    void initDatabase();
    void createTables();
    bool applyPragmas();
    bool execPragma(const QString &pragma, const QString &expectedValue = {});

    QSqlDatabase m_db;
    QString m_dbPath;
    mutable QMutex m_mutex;
    bool m_initialized = false;
};

} // namespace Lab