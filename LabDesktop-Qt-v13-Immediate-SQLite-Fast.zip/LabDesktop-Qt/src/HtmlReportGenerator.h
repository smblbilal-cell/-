#pragma once

#include "Models.h"

#include <QString>
#include <QStringList>

namespace Lab {

class HtmlReportGenerator {
public:
    // Generates a complete HTML report string.
    // Fully self-contained — no external file I/O, no template files.
    // Safe for portable .exe deployment.
    static QString generate(const AllSheetsData &data);

private:
    static QString generateIgG_IgM_Row(const TestItem &t, int rowNum);
    static QString generateQualitativeRow(const TestItem &t, int rowNum);
    static QString generateDropdownRow(const TestItem &t, int rowNum);
    static QString generateQuantitativeRow(const TestItem &t, int rowNum);
    static QString escapeHtml(const QString &s);
};

} // namespace Lab
