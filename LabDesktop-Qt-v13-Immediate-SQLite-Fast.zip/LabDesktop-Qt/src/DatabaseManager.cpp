#include "DatabaseManager.h"

namespace Lab {

// ═══════════════════════════════════════════════════════
//  Constructor / Destructor
// ═══════════════════════════════════════════════════════

DatabaseManager::DatabaseManager(QObject *parent)
    : QObject(parent)
{
    // Portable storage: beside the executable or in AppData
    QString appDir;
    if (QCoreApplication::applicationFilePath().endsWith(QLatin1String(".exe"))) {
        appDir = QFileInfo(QCoreApplication::applicationFilePath()).absolutePath();
    } else {
        appDir = QCoreApplication::applicationDirPath();
    }

    QString portableDir = appDir + QStringLiteral("/LabDesktopData");
    QDir().mkpath(portableDir);

    // Test write permission
    QString testFile = portableDir + QStringLiteral("/.write_test");
    if (QFile(testFile).open(QIODevice::WriteOnly | QIODevice::Append)) {
        QFile::remove(testFile);
        m_dbPath = portableDir + QStringLiteral("/labdata.db");
    } else {
        // Fallback to AppData
        QString appData = QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation)
                        + QStringLiteral("/LabDesktopData");
        QDir().mkpath(appData);
        m_dbPath = appData + QStringLiteral("/labdata.db");
    }

    initDatabase();
    qDebug() << "[DB] Storage:" << m_dbPath;
}

DatabaseManager::~DatabaseManager()
{
    // CRITICAL: Must close connection and remove database from Qt's registry
    // to prevent resource leaks and file locks on Windows
    QString connName;
    if (m_db.isOpen()) {
        connName = m_db.connectionName();
        m_db.close();
        qDebug() << "[DB] Connection closed cleanly";
    }
    if (!connName.isEmpty()) {
        QSqlDatabase::removeDatabase(connName);
    }
}

// ═══════════════════════════════════════════════════════
//  Initialization
// ═══════════════════════════════════════════════════════

void DatabaseManager::initDatabase()
{
    m_db = QSqlDatabase::addDatabase(QStringLiteral("QSQLITE"));
    if (!m_db.isValid()) {
        qCritical() << "[DB] QSQLITE driver not available!";
        emit error(QStringLiteral("محرك SQLite غير متوفر"));
        return;
    }

    m_db.setDatabaseName(m_dbPath);

    if (!m_db.open()) {
        qCritical() << "[DB] Open failed:" << m_db.lastError().text();
        emit error(QStringLiteral("فشل فتح قاعدة البيانات: ") + m_db.lastError().text());
        return;
    }

    if (!applyPragmas()) {
        qCritical() << "[DB] Pragmas failed, database may not perform optimally";
        // Non-fatal: continue with defaults
    }

    createTables();
    m_initialized = true;
    qDebug() << "[DB] Ready (foreign_keys=ON, WAL=ON)";
}

bool DatabaseManager::execPragma(const QString &pragma, const QString &expectedValue)
{
    QSqlQuery q(m_db);
    if (!q.exec(pragma)) {
        qWarning() << "[DB] PRAGMA failed:" << pragma << "-" << q.lastError().text();
        return false;
    }

    // Verify the pragma took effect
    if (!expectedValue.isEmpty()) {
        if (q.next() && q.value(0).toString().toLower() != expectedValue.toLower()) {
            qWarning() << "[DB] PRAGMA" << pragma << "returned unexpected value:"
                       << q.value(0).toString() << "(expected:" << expectedValue << ")";
            return false;
        }
    }

    qDebug() << "[DB] PRAGMA OK:" << pragma.simplified();
    return true;
}

bool DatabaseManager::applyPragmas()
{
    bool ok = true;

    // CRITICAL: Foreign Keys MUST be enabled per-connection, not in schema
    // SQLite defaults to OFF — enabling prevents orphaned records
    ok &= execPragma(QStringLiteral("PRAGMA foreign_keys = ON;"), QStringLiteral("1"));

    // WAL mode: concurrent reads + writes, no interface freezing
    ok &= execPragma(QStringLiteral("PRAGMA journal_mode = WAL;"), QStringLiteral("wal"));

    // NORMAL: balanced speed/safety for local desktop app
    // (FULL is overkill — WAL already provides crash recovery)
    ok &= execPragma(QStringLiteral("PRAGMA synchronous = NORMAL;"));

    // 8 MB cache for faster repeated reads of test data
    ok &= execPragma(QStringLiteral("PRAGMA cache_size = -8000;"));

    // Temp store in RAM (not on disk)
    ok &= execPragma(QStringLiteral("PRAGMA temp_store = MEMORY;"));

    // Busy timeout: wait up to 5 seconds if DB is locked by another process
    ok &= execPragma(QStringLiteral("PRAGMA busy_timeout = 5000;"));

    return ok;
}

void DatabaseManager::createTables()
{
    QSqlQuery q(m_db);

    // ── Key-value store for settings, full state, designs ──
    if (!q.exec(QStringLiteral(R"(
        CREATE TABLE IF NOT EXISTS app_settings (
            key   TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    )"))) {
        qCritical() << "[DB] app_settings creation error:" << q.lastError().text();
    }

    // ── Archive: saved patient records ───────────────
    if (!q.exec(QStringLiteral(R"(
        CREATE TABLE IF NOT EXISTS archive (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            saved_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            patient_name TEXT NOT NULL DEFAULT '',
            sheet_type  TEXT NOT NULL DEFAULT 'blood',
            state_json  TEXT NOT NULL
        )
    )"))) {
        qCritical() << "[DB] archive creation error:" << q.lastError().text();
    }

    // ── Normalized application state ─────────────────
    // One row per test. This avoids serializing the whole application on every edit.
    if (!q.exec(QStringLiteral(R"(
        CREATE TABLE IF NOT EXISTS tests (
            sheet_type TEXT NOT NULL,
            test_id INTEGER NOT NULL,
            name TEXT NOT NULL DEFAULT '',
            category TEXT NOT NULL DEFAULT '',
            normal_male TEXT NOT NULL DEFAULT '',
            normal_female TEXT NOT NULL DEFAULT '',
            normal_child TEXT NOT NULL DEFAULT '',
            unit TEXT NOT NULL DEFAULT '',
            checked INTEGER NOT NULL DEFAULT 0,
            result TEXT NOT NULL DEFAULT '',
            qualitative_type TEXT NOT NULL DEFAULT 'Quantitative',
            dropdown_options TEXT NOT NULL DEFAULT '',
            normal_igg TEXT NOT NULL DEFAULT '',
            normal_igm TEXT NOT NULL DEFAULT '',
            result_igg TEXT NOT NULL DEFAULT '',
            result_igm TEXT NOT NULL DEFAULT '',
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(sheet_type, test_id)
        )
    )"))) {
        qCritical() << "[DB] tests creation error:" << q.lastError().text();
    }

    if (!q.exec(QStringLiteral(R"(
        CREATE TABLE IF NOT EXISTS patient_state (
            id INTEGER PRIMARY KEY CHECK(id = 1),
            patient_name TEXT NOT NULL DEFAULT '',
            patient_date TEXT NOT NULL DEFAULT '',
            patient_gender TEXT NOT NULL DEFAULT 'Male',
            current_sheet TEXT NOT NULL DEFAULT 'blood',
            next_test_id INTEGER NOT NULL DEFAULT 423,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    )"))) {
        qCritical() << "[DB] patient_state creation error:" << q.lastError().text();
    }

    if (!q.exec(QStringLiteral("CREATE INDEX IF NOT EXISTS idx_tests_sheet ON tests(sheet_type);")))
        qWarning() << "[DB] tests index error:" << q.lastError().text();

    // ── Indexes for fast archive search ─────────────
    q.exec(QStringLiteral("CREATE INDEX IF NOT EXISTS idx_archive_name ON archive(patient_name);"));
    q.exec(QStringLiteral("CREATE INDEX IF NOT EXISTS idx_archive_date ON archive(saved_at);"));
    q.exec(QStringLiteral("CREATE INDEX IF NOT EXISTS idx_archive_sheet ON archive(sheet_type);"));

    // Verify with a test query
    if (!q.exec(QStringLiteral("SELECT count(*) FROM app_settings;"))) {
        qCritical() << "[DB] Verification query failed:" << q.lastError().text();
        m_initialized = false;
    }
}

// ═══════════════════════════════════════════════════════
//  Full State Save / Load
// ═══════════════════════════════════════════════════════

void DatabaseManager::saveFullState(const AllSheetsData &data)
{
    // Keep the legacy full_state row for backward compatibility, but make the
    // normalized tables the authoritative storage.
    if (!replaceAllTests(data)) {
        emit error(QStringLiteral("فشل الحفظ المباشر لبيانات التحاليل"));
        return;
    }

    QMutexLocker locker(&m_mutex);
    if (!m_db.isOpen()) return;
    QJsonDocument doc(data.toJson());
    QSqlQuery q(m_db);
    q.prepare(QStringLiteral("INSERT INTO app_settings(key,value,updated_at) VALUES('full_state',?,CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=CURRENT_TIMESTAMP"));
    q.addBindValue(QString::fromUtf8(doc.toJson(QJsonDocument::Compact)));
    if (!q.exec()) {
        emit error(QStringLiteral("فشل حفظ التوافق: ") + q.lastError().text());
        return;
    }
    emit stateSaved();
}

AllSheetsData DatabaseManager::loadFullState()
{
    QMutexLocker locker(&m_mutex);
    AllSheetsData data;
    if (!m_db.isOpen()) return data;

    // Prefer normalized state.
    QSqlQuery pq(m_db);
    if (pq.exec(QStringLiteral("SELECT patient_name, patient_date, patient_gender, current_sheet, next_test_id FROM patient_state WHERE id=1")) && pq.next()) {
        data.patient.name = pq.value(0).toString();
        data.patient.date = QDate::fromString(pq.value(1).toString(), Qt::ISODate);
        data.patient.gender = genderFromKey(pq.value(2).toString());
        data.currentSheet = sheetTypeFromKey(pq.value(3).toString());
        data.nextTestId = pq.value(4).toInt(423);
    }

    QSqlQuery tq(m_db);
    if (tq.exec(QStringLiteral("SELECT sheet_type,test_id,name,category,normal_male,normal_female,normal_child,unit,checked,result,qualitative_type,dropdown_options,normal_igg,normal_igm,result_igg,result_igm FROM tests ORDER BY sheet_type,test_id"))) {
        while (tq.next()) {
            TestItem t;
            t.id = tq.value(1).toInt();
            t.name = tq.value(2).toString();
            t.category = tq.value(3).toString();
            t.normalMale = tq.value(4).toString();
            t.normalFemale = tq.value(5).toString();
            t.normalChild = tq.value(6).toString();
            t.unit = tq.value(7).toString();
            t.checked = tq.value(8).toInt() != 0;
            t.result = tq.value(9).toString();
            t.qualitativeType = qualTypeFromKey(tq.value(10).toString());
            t.dropdownOptions = tq.value(11).toString();
            t.normalIgg = tq.value(12).toString();
            t.normalIgm = tq.value(13).toString();
            t.resultIgg = tq.value(14).toString();
            t.resultIgm = tq.value(15).toString();
            data.sheets[sheetTypeFromKey(tq.value(0).toString())].tests.append(t);
        }
    }

    // One-time migration from the legacy full_state JSON if normalized tables are empty.
    bool hasTests = false;
    for (auto it = data.sheets.cbegin(); it != data.sheets.cend(); ++it) {
        if (!it.value().tests.isEmpty()) { hasTests = true; break; }
    }
    if (!hasTests) {
        QSqlQuery legacy(m_db);
        if (legacy.exec(QStringLiteral("SELECT value FROM app_settings WHERE key='full_state'") ) && legacy.next()) {
            QJsonDocument doc = QJsonDocument::fromJson(legacy.value(0).toString().toUtf8());
            if (doc.isObject()) {
                data = AllSheetsData::fromJson(doc.object());
                locker.unlock();
                replaceAllTests(data);
                locker.relock();
            }
        }
    }

    emit stateLoaded(data);
    return data;
}

bool DatabaseManager::saveTest(SheetType sheet, const TestItem &test)
{
    QMutexLocker locker(&m_mutex);
    if (!m_db.isOpen() || !m_initialized) return false;
    QSqlQuery q(m_db);
    q.prepare(QStringLiteral(R"(
        INSERT OR REPLACE INTO tests (sheet_type,test_id,name,category,normal_male,normal_female,normal_child,unit,checked,result,qualitative_type,dropdown_options,normal_igg,normal_igm,result_igg,result_igm,updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
    )"));
    q.addBindValue(sheetTypeKey(sheet)); q.addBindValue(test.id); q.addBindValue(test.name); q.addBindValue(test.category);
    q.addBindValue(test.normalMale); q.addBindValue(test.normalFemale); q.addBindValue(test.normalChild); q.addBindValue(test.unit);
    q.addBindValue(test.checked ? 1 : 0); q.addBindValue(test.result); q.addBindValue(qualTypeKey(test.qualitativeType)); q.addBindValue(test.dropdownOptions);
    q.addBindValue(test.normalIgg); q.addBindValue(test.normalIgm); q.addBindValue(test.resultIgg); q.addBindValue(test.resultIgm);
    if (!q.exec()) { emit error(QStringLiteral("فشل حفظ التحليل: ") + q.lastError().text()); return false; }
    emit stateSaved();
    return true;
}

bool DatabaseManager::savePatient(const PatientData &patient, SheetType currentSheet, int nextTestId)
{
    QMutexLocker locker(&m_mutex);
    if (!m_db.isOpen() || !m_initialized) return false;
    QSqlQuery q(m_db);
    q.prepare(QStringLiteral(R"(
        INSERT OR REPLACE INTO patient_state(id,patient_name,patient_date,patient_gender,current_sheet,next_test_id,updated_at)
        VALUES(1,?,?,?,?,?,CURRENT_TIMESTAMP)
    )"));
    q.addBindValue(patient.name); q.addBindValue(patient.date.toString(Qt::ISODate));
    q.addBindValue(genderKey(patient.gender)); q.addBindValue(sheetTypeKey(currentSheet)); q.addBindValue(nextTestId);
    if (!q.exec()) { emit error(QStringLiteral("فشل حفظ بيانات المريض: ") + q.lastError().text()); return false; }
    emit stateSaved();
    return true;
}

bool DatabaseManager::saveSheetChecks(SheetType sheet, const QVector<TestItem> &tests)
{
    if (tests.isEmpty()) return true;
    QMutexLocker locker(&m_mutex);
    if (!m_db.isOpen() || !m_initialized) return false;
    if (!m_db.transaction()) return false;
    QSqlQuery q(m_db);
    q.prepare(QStringLiteral("UPDATE tests SET checked=?, updated_at=CURRENT_TIMESTAMP WHERE sheet_type=? AND test_id=?"));
    for (const auto &t : tests) {
        q.bindValue(0, t.checked ? 1 : 0); q.bindValue(1, sheetTypeKey(sheet)); q.bindValue(2, t.id);
        if (!q.exec()) { m_db.rollback(); emit error(QStringLiteral("فشل حفظ تحديد التحاليل: ") + q.lastError().text()); return false; }
        q.finish();
    }
    if (!m_db.commit()) { m_db.rollback(); return false; }
    emit stateSaved();
    return true;
}

bool DatabaseManager::replaceAllTests(const AllSheetsData &data)
{
    QMutexLocker locker(&m_mutex);
    if (!m_db.isOpen() || !m_initialized) return false;
    if (!m_db.transaction()) return false;
    QSqlQuery clear(m_db);
    if (!clear.exec(QStringLiteral("DELETE FROM tests"))) { m_db.rollback(); return false; }
    QSqlQuery q(m_db);
    q.prepare(QStringLiteral("INSERT INTO tests(sheet_type,test_id,name,category,normal_male,normal_female,normal_child,unit,checked,result,qualitative_type,dropdown_options,normal_igg,normal_igm,result_igg,result_igm) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"));
    const auto keys = {SheetType::Blood,SheetType::Stool,SheetType::Urine,SheetType::Semen};
    for (auto sheet : keys) {
        for (const auto &t : data.sheets.value(sheet).tests) {
            q.bindValue(0, sheetTypeKey(sheet)); q.bindValue(1, t.id); q.bindValue(2, t.name); q.bindValue(3, t.category);
            q.bindValue(4, t.normalMale); q.bindValue(5, t.normalFemale); q.bindValue(6, t.normalChild); q.bindValue(7, t.unit);
            q.bindValue(8, t.checked ? 1 : 0); q.bindValue(9, t.result); q.bindValue(10, qualTypeKey(t.qualitativeType));
            q.bindValue(11, t.dropdownOptions); q.bindValue(12, t.normalIgg); q.bindValue(13, t.normalIgm);
            q.bindValue(14, t.resultIgg); q.bindValue(15, t.resultIgm);
            if (!q.exec()) { m_db.rollback(); emit error(QStringLiteral("فشل ترحيل التحاليل: ") + q.lastError().text()); return false; }
        }
    }
    if (!m_db.commit()) { m_db.rollback(); return false; }
    // Patient state is a small row and is safe to save separately.
    locker.unlock();
    savePatient(data.patient, data.currentSheet, data.nextTestId);
    return true;
}

bool DatabaseManager::backupDatabase(const QString &filePath)
{
    QMutexLocker locker(&m_mutex);
    if (!m_db.isOpen() || filePath.isEmpty()) return false;
    if (QFile::exists(filePath) && !QFile::remove(filePath)) {
        emit error(QStringLiteral("لا يمكن استبدال ملف النسخة الاحتياطية"));
        return false;
    }
    QSqlQuery q(m_db);
    q.prepare(QStringLiteral("VACUUM INTO ?"));
    q.addBindValue(filePath);
    if (!q.exec()) { emit error(QStringLiteral("فشل إنشاء نسخة SQLite: ") + q.lastError().text()); return false; }
    return true;
}

bool DatabaseManager::restoreDatabase(const QString &filePath)
{
    QMutexLocker locker(&m_mutex);
    if (!m_db.isOpen() || filePath.isEmpty()) return false;
    // Replace database contents safely by reading the backup through a temporary connection.
    const QString conn = QStringLiteral("restore_connection_%1").arg(reinterpret_cast<quintptr>(this));
    QSqlDatabase src = QSqlDatabase::addDatabase(QStringLiteral("QSQLITE"), conn);
    src.setDatabaseName(filePath);
    if (!src.open()) { QSqlDatabase::removeDatabase(conn); return false; }
    QSqlQuery qsrc(src);
    if (!qsrc.exec(QStringLiteral("SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"))) { src.close(); QSqlDatabase::removeDatabase(conn); return false; }
    QStringList tables;
    while (qsrc.next()) tables << qsrc.value(0).toString();
    if (tables.isEmpty()) { src.close(); QSqlDatabase::removeDatabase(conn); return false; }
    if (!m_db.transaction()) { src.close(); QSqlDatabase::removeDatabase(conn); return false; }
    QSqlQuery dst(m_db);
    const QStringList allowedTables = {QStringLiteral("app_settings"), QStringLiteral("archive"), QStringLiteral("tests"), QStringLiteral("patient_state")};
    // Start from a clean state so restoring an older backup cannot leave stale rows behind.
    for (const auto &name : allowedTables) {
        if (!dst.exec(QStringLiteral("DELETE FROM %1").arg(name))) { m_db.rollback(); src.close(); QSqlDatabase::removeDatabase(conn); return false; }
    }
    for (const auto &t : tables) {
        if (!allowedTables.contains(t)) continue;
        QSqlQuery rows(src);
        if (!rows.exec(QStringLiteral("SELECT * FROM %1").arg(t))) { m_db.rollback(); src.close(); QSqlDatabase::removeDatabase(conn); return false; }
        int n = rows.record().count();
        while (rows.next()) {
            QStringList marks; for (int i=0;i<n;++i) marks << QStringLiteral("?");
            QSqlQuery ins(m_db); ins.prepare(QStringLiteral("INSERT INTO %1 VALUES(%2)").arg(t, marks.join(',')));
            for (int i=0;i<n;++i) ins.addBindValue(rows.value(i));
            if (!ins.exec()) { m_db.rollback(); src.close(); QSqlDatabase::removeDatabase(conn); return false; }
        }
    }
    bool ok=m_db.commit();
    src.close();
    QSqlDatabase::removeDatabase(conn);
    return ok;
}

// ═══════════════════════════════════════════════════════
//  Key-Value Helpers
// ═══════════════════════════════════════════════════════

void DatabaseManager::setValue(const QString &key, const QString &value)
{
    if (key.isEmpty()) return; // Guard: empty key is invalid

    QMutexLocker locker(&m_mutex);
    if (!m_db.isOpen()) return;

    QSqlQuery q(m_db);
    q.prepare(QStringLiteral(
        "INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)"
    ));
    q.addBindValue(key);
    q.addBindValue(value);
    if (!q.exec()) {
        qWarning() << "[DB] setValue error for key" << key << ":" << q.lastError().text();
    }
}

QString DatabaseManager::value(const QString &key, const QString &defaultValue) const
{
    if (key.isEmpty()) return defaultValue; // Guard

    QMutexLocker locker(&m_mutex);
    if (!m_db.isOpen()) return defaultValue;

    QSqlQuery q(m_db);
    q.prepare(QStringLiteral("SELECT value FROM app_settings WHERE key = ?"));
    q.addBindValue(key);
    if (!q.exec()) {
        qWarning() << "[DB] value() error for key" << key << ":" << q.lastError().text();
        return defaultValue;
    }

    if (q.next()) {
        return q.value(0).toString();
    }
    return defaultValue;
}

// ═══════════════════════════════════════════════════════
//  Archive
// ═══════════════════════════════════════════════════════

bool DatabaseManager::archiveCurrentState(const AllSheetsData &data)
{
    QMutexLocker locker(&m_mutex);
    if (!m_db.isOpen()) return false;

    QJsonObject state = data.toJson();
    QJsonDocument doc(state);
    QString json = QString::fromUtf8(doc.toJson(QJsonDocument::Compact));

    QSqlQuery q(m_db);
    q.prepare(QStringLiteral(
        "INSERT INTO archive (patient_name, sheet_type, state_json) VALUES (?, ?, ?)"
    ));
    q.addBindValue(data.patient.name.isEmpty() ? QStringLiteral("unnamed") : data.patient.name);
    q.addBindValue(sheetTypeKey(data.currentSheet));
    q.addBindValue(json);

    if (!q.exec()) {
        qCritical() << "[DB] Archive insert error:" << q.lastError().text();
        return false;
    }

    qDebug() << "[DB] Archived:" << data.patient.name;
    return true;
}

// ═══════════════════════════════════════════════════════
//  Import / Export JSON
// ═══════════════════════════════════════════════════════

bool DatabaseManager::exportToJsonFile(const QString &filePath, const AllSheetsData &data)
{
    if (filePath.isEmpty()) {
        emit error(QStringLiteral("مسار الملف فارغ"));
        return false;
    }

    QJsonObject obj = data.toJson();
    QJsonDocument doc(obj);

    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly)) {
        emit error(QStringLiteral("فشل فتح الملف للتصدير: ") + filePath);
        return false;
    }

    qint64 written = file.write(doc.toJson(QJsonDocument::Indented));
    file.close();

    if (written <= 0) {
        emit error(QStringLiteral("فشل كتابة البيانات"));
        return false;
    }

    qDebug() << "[DB] Exported to" << filePath << "(" << written << " bytes)";
    return true;
}

AllSheetsData DatabaseManager::importFromJsonFile(const QString &filePath)
{
    if (filePath.isEmpty()) {
        emit error(QStringLiteral("مسار الملف فارغ"));
        return {};
    }

    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) {
        emit error(QStringLiteral("فشل قراءة ملف الاستيراد: ") + filePath);
        return {};
    }

    QByteArray raw = file.readAll();
    file.close();

    if (raw.isEmpty()) {
        emit error(QStringLiteral("الملف فارغ"));
        return {};
    }

    QJsonParseError parseError;
    QJsonDocument doc = QJsonDocument::fromJson(raw, &parseError);
    if (parseError.error != QJsonParseError::NoError) {
        emit error(QStringLiteral("خطأ تحليل JSON: ") + parseError.errorString()
                   + QStringLiteral(" (سطر %1)").arg(parseError.offset));
        return {};
    }

    if (!doc.isObject()) {
        emit error(QStringLiteral("ملف غير صالح: الجذر ليس كائن JSON"));
        return {};
    }

    qDebug() << "[DB] Imported from" << filePath;
    return AllSheetsData::fromJson(doc.object());
}

} // namespace Lab
