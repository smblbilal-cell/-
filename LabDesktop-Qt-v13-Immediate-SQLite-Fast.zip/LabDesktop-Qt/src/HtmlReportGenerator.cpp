#include "HtmlReportGenerator.h"

namespace Lab {

// ═══════════════════════════════════════════════════════
//  NOTE: This generator is FULLY SELF-CONTAINED.
//  It does NOT read from any external template files.
//  All HTML is generated dynamically via QString construction.
//  No filesystem paths are used — safe for portable .exe deployment.
// ═══════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════
//  Main Generate
// ═══════════════════════════════════════════════════════

QString HtmlReportGenerator::generate(const AllSheetsData &data)
{
    const auto &patient = data.patient;
    const auto &sheet = data.currentSheetData();
    SheetType sheetType = data.currentSheet;

    QString title;
    if (sheetType == SheetType::Blood) {
        title = QStringLiteral("Blood Test Report");
    } else {
        title = sheetTypeTitle(sheetType);
    }

    QString sheetColor = sheetTypeColor(sheetType);
    auto checked = sheet.checkedTests();

    // Build rows with a single sequential counter
    QString rows;
    int rowNum = 0;
    for (const auto &t : checked) {
        ++rowNum;
        switch (t.qualitativeType) {
        case QualType::IgG_IgM:
            rows += generateIgG_IgM_Row(t, rowNum);
            break;
        case QualType::Qualitative:
        case QualType::SimpleQualitative:
            rows += generateQualitativeRow(t, rowNum);
            break;
        case QualType::Dropdown:
            rows += generateDropdownRow(t, rowNum);
            break;
        default:
            rows += generateQuantitativeRow(t, rowNum);
            break;
        }
    }

    if (rows.isEmpty()) {
        rows = QStringLiteral(R"(
            <tr><td colspan='5' style='text-align:center;padding:40px;color:#999;'>
                لم يتم اختيار أي تحليل
            </td></tr>
        )");
    }

    QString genderAr = patient.gender == Gender::Female ? QStringLiteral("أنثى")
                     : patient.gender == Gender::Child  ? QStringLiteral("طفل")
                     : QStringLiteral("ذكر");

    return QStringLiteral(R"(<!DOCTYPE html>
<html dir='rtl' lang='ar'>
<head>
<meta charset='UTF-8'>
<style>
    @page { size: A4; margin: 8mm; }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
        font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
        font-size: 11px;
        color: #222;
        background: #fff;
        max-width: 210mm;
        margin: 0 auto;
        padding: 6mm;
    }
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 3px solid %1;
        padding-bottom: 8px;
        margin-bottom: 12px;
    }
    .header h1 { font-size: 16px; color: %1; }
    .header .lab-name { font-size: 13px; font-weight: bold; }
    .patient-info {
        display: flex;
        gap: 30px;
        margin-bottom: 12px;
        padding: 6px 10px;
        background: #f8f9fa;
        border-radius: 4px;
        font-size: 12px;
    }
    .patient-info span { font-weight: bold; }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 8px;
    }
    th {
        background: %1;
        color: #fff;
        padding: 6px 8px;
        text-align: right;
        font-size: 11px;
    }
    td {
        padding: 5px 8px;
        border-bottom: 1px solid #e0e0e0;
        font-size: 11px;
    }
    tr:nth-child(even) { background: #f9f9f9; }
    tr:hover { background: #e8f4fd; }
    .result-cell { font-weight: bold; color: #1a5276; }
    .abnormal { color: #c0392b; font-weight: bold; }
    .footer {
        margin-top: 20px;
        padding-top: 8px;
        border-top: 2px solid %1;
        display: flex;
        justify-content: space-between;
        font-size: 9px;
        color: #888;
    }
    .signature { margin-top: 50px; text-align: center; }
    .signature-line { border-top: 1px solid #333; width: 200px; margin: 5px auto 0; }
    @media print {
        body { padding: 0; }
        .no-print { display: none; }
    }
</style>
</head>
<body>

    <div class='header'>
        <div class='lab-name'>المختبر</div>
        <h1>%2</h1>
    </div>

    <div class='patient-info'>
        <div>الاسم: <span>%3</span></div>
        <div>التاريخ: <span>%4</span></div>
        <div>الجنس: <span>%5</span></div>
    </div>

    <table>
        <thead>
            <tr>
                <th style='width:5%%'>#</th>
                <th style='width:30%%'>التحليل</th>
                <th style='width:25%%'>النتيجة</th>
                <th style='width:25%%'>القيمة الطبيعية</th>
                <th style='width:15%%'>الوحدة</th>
            </tr>
        </thead>
        <tbody>
            %6
        </tbody>
    </table>

    <div class='footer'>
        <div>طباعة: %7</div>
        <div>نظام مختبر التحليلات المتقدم v12 (C++/Qt)</div>
    </div>

    <div class='signature'>
        <p>التوقيع / الختم</p>
        <div class='signature-line'></div>
    </div>

</body>
</html>)").arg(
        sheetColor,
        escapeHtml(title),
        escapeHtml(patient.name),
        patient.date.isValid() ? patient.date.toString(QStringLiteral("yyyy-MM-dd")) : QStringLiteral("---"),
        genderAr,
        rows,
        QDateTime::currentDateTime().toString(QStringLiteral("yyyy-MM-dd hh:mm:ss"))
    );
}

// ═══════════════════════════════════════════════════════
//  Row Generators (num passed as parameter, no static state)
// ═══════════════════════════════════════════════════════

QString HtmlReportGenerator::generateQuantitativeRow(const TestItem &t, int num)
{
    QString resultClass = t.result.isEmpty() ? QStringLiteral("") : QStringLiteral("result-cell");
    return QStringLiteral(
        "<tr><td>%1</td><td>%2</td><td class='%3'>%4</td><td>%5</td><td>%6</td></tr>"
    ).arg(num).arg(
        escapeHtml(t.name),
        resultClass,
        escapeHtml(t.result),
        escapeHtml(t.normalMale),
        escapeHtml(t.unit)
    );
}

QString HtmlReportGenerator::generateDropdownRow(const TestItem &t, int num)
{
    return QStringLiteral(
        "<tr><td>%1</td><td>%2</td><td class='result-cell'>%3</td><td>%4</td><td>%5</td></tr>"
    ).arg(num).arg(
        escapeHtml(t.name),
        escapeHtml(t.result),
        escapeHtml(t.normalMale),
        escapeHtml(t.unit)
    );
}

QString HtmlReportGenerator::generateQualitativeRow(const TestItem &t, int num)
{
    QString result = t.result;
    QString cls;
    if (result.contains(QLatin1String("Positive"), Qt::CaseInsensitive))
        cls = QStringLiteral("abnormal");
    else if (!result.isEmpty())
        cls = QStringLiteral("result-cell");

    return QStringLiteral(
        "<tr><td>%1</td><td>%2</td><td class='%3'>%4</td><td>%5</td><td></td></tr>"
    ).arg(num).arg(
        escapeHtml(t.name),
        cls,
        escapeHtml(result),
        escapeHtml(t.normalMale)
    );
}

QString HtmlReportGenerator::generateIgG_IgM_Row(const TestItem &t, int num)
{
    return QStringLiteral(
        "<tr><td>%1</td><td>%2</td><td class='result-cell'>IgG: %3  |  IgM: %4</td><td>Normal: IgG %5 / IgM %6</td><td></td></tr>"
    ).arg(num).arg(
        escapeHtml(t.name),
        escapeHtml(t.resultIgg),
        escapeHtml(t.resultIgm),
        escapeHtml(t.normalIgg),
        escapeHtml(t.normalIgm)
    );
}

// ═══════════════════════════════════════════════════════
//  Helpers
// ═══════════════════════════════════════════════════════

QString HtmlReportGenerator::escapeHtml(const QString &s)
{
    QString out = s;
    out.replace(QLatin1Char('&'),  QStringLiteral("&amp;"));
    out.replace(QLatin1Char('<'),  QStringLiteral("&lt;"));
    out.replace(QLatin1Char('>'),  QStringLiteral("&gt;"));
    out.replace(QLatin1Char('"'), QStringLiteral("&quot;"));
    return out;
}

} // namespace Lab