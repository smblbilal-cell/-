#pragma once

#include <QWidget>

class QWebEngineView;
class QPrinter;

namespace Lab {

class ReportWidget : public QWidget {
    Q_OBJECT

public:
    explicit ReportWidget(QWidget *parent = nullptr);

    void setHtml(const QString &html);
    void print(QPrinter *printer);

    // Get report as PNG for clipboard/WhatsApp
    QPixmap captureReport();

private:
    QWebEngineView *m_webView = nullptr;
};

} // namespace Lab