#include "MainWindow.h"
#include "TestSelectionDialog.h"
#include "ReportWidget.h"
#include "HtmlReportGenerator.h"

#include <QApplication>
#include <QMessageBox>
#include <QFileDialog>
#include <QHeaderView>
#include <QCloseEvent>
#include <QScrollBar>
#include <QPainter>
#include <QPrinter>
#include <QPrintDialog>
#include <QJsonObject>
#include <QJsonDocument>
#include <QBuffer>
#include <QClipboard>
#include <QElapsedTimer>

#ifdef Q_OS_WIN
#include <windows.h>
#endif

namespace Lab {

// ═══════════════════════════════════════════════════════
//  Constructor
// ═══════════════════════════════════════════════════════

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , m_db(new DatabaseManager(this))
    , m_sound(new SoundManager(this))
{
    setWindowTitle(QStringLiteral("نظام مختبر التحليلات المتقدم v12"));
    resize(1400, 920);
    setMinimumSize(900, 600);

    // Install application-level event filter for sounds
    qApp->installEventFilter(this);

    setupUI();
    setupMenuBar();
    setupToolbar();
    setupSoundControls();
    applyStyle();

    // Verify DB is ready
    if (!m_db || !m_db->isReady()) {
        QMessageBox::warning(this, tr("تحذير"),
            tr("قاعدة البيانات غير جاهزة. سيتم استخدام البيانات الافتراضية."));
    }

    // Load saved state from DB
    if (m_db) {
        m_data = m_db->loadFullState();
    }
    if (m_data.sheets.isEmpty()) {
        loadDefaultTests();
        if (m_db) m_db->replaceAllTests(m_data);
    }

    // Restore patient fields (with null guards)
    if (m_patientNameEdit)    m_patientNameEdit->setText(m_data.patient.name);
    if (m_patientDateEdit)    m_patientDateEdit->setDate(m_data.patient.date.isValid()
                                                              ? m_data.patient.date
                                                              : QDate::currentDate());
    if (m_patientGenderCombo) m_patientGenderCombo->setCurrentIndex(
                                  qBound(0, static_cast<int>(m_data.patient.gender), 2));

    // Restore active sheet tab
    if (m_sheetTabs) {
        int tabIdx = qBound(0, static_cast<int>(m_data.currentSheet), 3);
        m_sheetTabs->setCurrentIndex(tabIdx);
    }

    populateTestTable();
    updateReportPreview();

    showStatusBarMessage(tr("جاهز"));
}

MainWindow::~MainWindow() = default;

// ═══════════════════════════════════════════════════════
//  Event Filter — sounds for typing, buttons, language
// ═══════════════════════════════════════════════════════

bool MainWindow::eventFilter(QObject *watched, QEvent *event)
{
    if (!m_sound) return QMainWindow::eventFilter(watched, event);

    switch (event->type()) {

    // ── Typing sound for text fields ─────────────
    case QEvent::KeyPress: {
        auto *ke = static_cast<QKeyEvent*>(event);
        if (!ke->text().isEmpty() && !ke->isAutoRepeat()) {
            bool isTextField = (qobject_cast<QLineEdit*>(watched) != nullptr);
            if (!isTextField && watched->parent()) {
                isTextField = (qobject_cast<QLineEdit*>(watched) != nullptr);
            }
            if (isTextField) {
                qint64 now = QElapsedTimer::currentMSecsSinceEpoch();
                if (now - m_lastTypeSoundMs >= 60) {
                    m_lastTypeSoundMs = now;
                    m_sound->play(SoundManager::TypeClick);
                }
            }
        }
        break;
    }

    // ── Language change detection ─────────────────
    case QEvent::KeyboardLayoutChange: {
#ifdef Q_OS_WIN
        HKL hkl = GetKeyboardLayout(GetCurrentThreadId());
        WORD langId = LOWORD(hkl);
        if (langId == 0x0409) {
            m_sound->play(SoundManager::LangChange);
            showStatusBarMessage(tr("⚠ تم التبديل إلى الإنجليزية"), 2000);
        }
#endif
        break;
    }

    // ── Button click sound ────────────────────────
    case QEvent::MouseButtonPress: {
        if (qobject_cast<QAbstractButton*>(watched)) {
            m_sound->play(SoundManager::ButtonClick);
        }
        break;
    }

    default:
        break;
    }

    return QMainWindow::eventFilter(watched, event);
}

// ═══════════════════════════════════════════════════════
//  Close Event
// ═══════════════════════════════════════════════════════

void MainWindow::closeEvent(QCloseEvent *event)
{
    if (m_db) m_db->saveFullState(m_data);
    event->accept();
}

// ═══════════════════════════════════════════════════════
//  Setup UI
// ═══════════════════════════════════════════════════════

void MainWindow::setupUI()
{
    auto *centralWidget = new QWidget(this);
    auto *mainLayout = new QVBoxLayout(centralWidget);
    mainLayout->setContentsMargins(4, 4, 4, 4);
    mainLayout->setSpacing(4);
    setCentralWidget(centralWidget);

    m_mainSplitter = new QSplitter(Qt::Horizontal, this);
    mainLayout->addWidget(m_mainSplitter);

    auto *leftPanel = new QWidget(this);
    auto *leftLayout = new QVBoxLayout(leftPanel);
    leftLayout->setContentsMargins(0, 0, 0, 0);
    leftLayout->setSpacing(4);

    setupPatientPanel();
    setupSheetTabs();
    setupTestTable();

    if (m_patientNameEdit && m_patientNameEdit->parentWidget())
        leftLayout->addWidget(m_patientNameEdit->parentWidget());
    if (m_sheetTabs)  leftLayout->addWidget(m_sheetTabs);
    if (m_testTable)  leftLayout->addWidget(m_testTable, 1);

    m_mainSplitter->addWidget(leftPanel);

    setupReportPanel();
    if (m_reportWidget) m_mainSplitter->addWidget(m_reportWidget);

    m_mainSplitter->setSizes({500, 900});
    m_mainSplitter->setStretchFactor(0, 0);
    m_mainSplitter->setStretchFactor(1, 1);

    m_statusLabel = new QLabel(this);
    if (statusBar()) statusBar()->addWidget(m_statusLabel, 1);
}

void MainWindow::setupPatientPanel()
{
    auto *group = new QGroupBox(tr("بيانات المريض"), this);
    auto *layout = new QHBoxLayout(group);
    layout->setContentsMargins(8, 4, 8, 4);

    auto *nameLabel = new QLabel(tr("الاسم:"), this);
    m_patientNameEdit = new QLineEdit(this);
    m_patientNameEdit->setPlaceholderText(tr("اسم المريض"));
    m_patientNameEdit->setMinimumWidth(200);
    connect(m_patientNameEdit, &QLineEdit::textChanged,
            this, &MainWindow::onPatientNameChanged);

    auto *dateLabel = new QLabel(tr("التاريخ:"), this);
    m_patientDateEdit = new QDateEdit(QDate::currentDate(), this);
    m_patientDateEdit->setCalendarPopup(true);
    m_patientDateEdit->setDisplayFormat("yyyy-MM-dd");
    connect(m_patientDateEdit, &QDateEdit::dateChanged,
            this, &MainWindow::onPatientDateChanged);

    auto *genderLabel = new QLabel(tr("الجنس:"), this);
    m_patientGenderCombo = new QComboBox(this);
    m_patientGenderCombo->addItems({tr("ذكر"), tr("أنثى"), tr("طفل")});
    connect(m_patientGenderCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &MainWindow::onPatientGenderChanged);

    m_btnNewPatient = new QPushButton(tr("🔄 مريض جديد"), this);
    m_btnNewPatient->setToolTip(tr("مسح البيانات وبدء مريض جديد"));
    connect(m_btnNewPatient, &QPushButton::clicked, this, &MainWindow::onNewPatient);

    layout->addWidget(nameLabel);
    layout->addWidget(m_patientNameEdit, 1);
    layout->addWidget(dateLabel);
    layout->addWidget(m_patientDateEdit);
    layout->addWidget(genderLabel);
    layout->addWidget(m_patientGenderCombo);
    layout->addWidget(m_btnNewPatient);
}

void MainWindow::setupSheetTabs()
{
    m_sheetTabs = new QTabWidget(this);

    const struct { QString label; QString color; } tabs[] = {
        {tr("دم  Blood"),         QStringLiteral("#e74c3c")},
        {tr("براز  Stool"),       QStringLiteral("#8B4513")},
        {tr("بول  Urine"),        QStringLiteral("#f39c12")},
        {tr("سائل منوي  Semen"),  QStringLiteral("#9b59b6")},
    };

    for (int i = 0; i < 4; ++i) {
        auto *tab = new QWidget();
        m_sheetTabs->addTab(tab, tabs[i].label);
        QString style = QString(
            "QTabBar::tab:nth-child(%1) { color: %2; font-weight: bold; }"
        ).arg(i + 1).arg(tabs[i].color);
        m_sheetTabs->setStyleSheet(m_sheetTabs->styleSheet() + style);
    }

    connect(m_sheetTabs, &QTabWidget::currentChanged,
            this, &MainWindow::onSheetChanged);
}

void MainWindow::setupTestTable()
{
    m_testTable = new QTableWidget(this);
    m_testTable->setColumnCount(6);
    m_testTable->setHorizontalHeaderLabels({
        tr(""), tr("التحليل"), tr("القيمة الطبيعية"),
        tr("الوحدة"), tr("النتيجة"), tr("النوع")
    });

    auto *header = m_testTable->horizontalHeader();
    if (header) {
        header->setSectionResizeMode(0, QHeaderView::ResizeToContents);
        header->setSectionResizeMode(1, QHeaderView::Stretch);
        header->setSectionResizeMode(2, QHeaderView::ResizeToContents);
        header->setSectionResizeMode(3, QHeaderView::ResizeToContents);
        header->setSectionResizeMode(4, QHeaderView::Stretch);
        header->setSectionResizeMode(5, QHeaderView::ResizeToContents);
    }

    m_testTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_testTable->setEditTriggers(QAbstractItemView::DoubleClicked | QAbstractItemView::SelectedClicked);
    m_testTable->verticalHeader()->setDefaultSectionSize(28);
    m_testTable->setAlternatingRowColors(true);

    connect(m_testTable, &QTableWidget::cellChanged,
            this, &MainWindow::onTestCellChanged);
}

void MainWindow::setupReportPanel()
{
    m_reportWidget = new ReportWidget(this);
}

// ═══════════════════════════════════════════════════════
//  Sound Controls — volume slider + mute in toolbar
// ═══════════════════════════════════════════════════════

void MainWindow::setupSoundControls()
{
    auto toolbars = findChildren<QToolBar*>();
    if (toolbars.isEmpty()) return;
    auto *toolbar = toolbars.first();

    toolbar->addSeparator();

    // Volume label
    auto *volLabel = new QLabel(tr("  🔊 "), this);
    volLabel->setToolTip(tr("مستوى الصوت"));
    toolbar->addWidget(volLabel);

    // Volume slider
    m_volumeSlider = new QSlider(Qt::Horizontal, this);
    m_volumeSlider->setRange(0, 100);
    m_volumeSlider->setValue(static_cast<int>(m_sound->volume() * 100));
    m_volumeSlider->setFixedWidth(100);
    m_volumeSlider->setToolTip(tr("مستوى الصوت: %1%").arg(m_volumeSlider->value()));
    toolbar->addWidget(m_volumeSlider);
    connect(m_volumeSlider, &QSlider::valueChanged, this, &MainWindow::onVolumeChanged);

    // Mute toggle button
    m_btnMute = new QPushButton(tr("🔊"), this);
    m_btnMute->setFixedWidth(32);
    m_btnMute->setToolTip(tr("كتم / تشغيل الصوت"));
    connect(m_btnMute, &QPushButton::clicked, this, &MainWindow::onToggleMute);
    toolbar->addWidget(m_btnMute);
}

void MainWindow::onVolumeChanged(int value)
{
    if (m_sound) {
        m_sound->setVolume(value / 100.0);
        if (m_volumeSlider)
            m_volumeSlider->setToolTip(tr("مستوى الصوت: %1%").arg(value));
    }
}

void MainWindow::onToggleMute()
{
    if (!m_sound) return;
    m_sound->toggleMute();
    if (m_btnMute) {
        m_btnMute->setText(m_sound->isMuted() ? tr("🔇") : tr("🔊"));
        m_btnMute->setToolTip(m_sound->isMuted() ? tr("تشغيل الصوت") : tr("كتم الصوت"));
    }
}

void MainWindow::onToggleSounds()
{
    if (!m_sound) return;
    m_sound->setEnabled(!m_sound->isEnabled());
    showStatusBarMessage(m_sound->isEnabled() ? tr("الأصوات مفعلة") : tr("الأصوات معطلة"));
}

// ═══════════════════════════════════════════════════════
//  Menu Bar
// ═══════════════════════════════════════════════════════

void MainWindow::setupMenuBar()
{
    auto *menuBar = this->menuBar();
    if (!menuBar) return;

    // File menu
    auto *fileMenu = menuBar->addMenu(tr("ملف"));
    if (fileMenu) {
        fileMenu->addAction(tr("🔄 مريض جديد"), this, &MainWindow::onNewPatient, QKeySequence::New);
        fileMenu->addSeparator();
        fileMenu->addAction(tr("💾 حفظ"), this, &MainWindow::onSaveState, QKeySequence::Save);
        fileMenu->addAction(tr("📤 تصدير JSON..."), this, &MainWindow::onExportJson);
        fileMenu->addAction(tr("📥 استيراد JSON..."), this, &MainWindow::onImportJson);
        fileMenu->addAction(tr("🗄 نسخة احتياطية SQLite..."), this, &MainWindow::onBackupSqlite);
        fileMenu->addAction(tr("♻ استعادة نسخة SQLite..."), this, &MainWindow::onRestoreSqlite);
        fileMenu->addSeparator();
        fileMenu->addAction(tr("🚪 خروج"), this, &QWidget::close, QKeySequence::Quit);
    }

    // Edit menu
    auto *editMenu = menuBar->addMenu(tr("تحرير"));
    if (editMenu) {
        editMenu->addAction(tr("☑  اختيار التحاليل..."), this, &MainWindow::onSelectTests);
        editMenu->addAction(tr("☑  تحديد الكل"), [this]() { setAllTestsChecked(true); });
        editMenu->addAction(tr("☐  إلغاء التحديد"), [this]() { setAllTestsChecked(false); });
    }

    // Report menu
    auto *reportMenu = menuBar->addMenu(tr("تقرير"));
    if (reportMenu) {
        reportMenu->addAction(tr("🖨️ طباعة"), this, &MainWindow::onPrintReport, QKeySequence::Print);
        reportMenu->addAction(tr("🔄 تحديث المعاينة"), this, &MainWindow::onRefreshReport);
    }

    // Sounds menu
    auto *soundMenu = menuBar->addMenu(tr("أصوات"));
    if (soundMenu) {
        auto *toggleAction = soundMenu->addAction(tr("تشغيل / إيقاف الأصوات"));
        toggleAction->setCheckable(true);
        toggleAction->setChecked(true);
        connect(toggleAction, &QAction::toggled, this, [this](bool on) {
            if (m_sound) {
                m_sound->setEnabled(on);
                showStatusBarMessage(on ? tr("الأصوات مفعلة") : tr("الأصوات معطلة"));
            }
        });
    }
}

// ═══════════════════════════════════════════════════════
//  Toolbar
// ═══════════════════════════════════════════════════════

void MainWindow::setupToolbar()
{
    auto *toolbar = addToolBar(tr("أدوات"));
    if (!toolbar) return;
    toolbar->setMovable(false);
    toolbar->setIconSize(QSize(20, 20));

    m_btnNewPatient = new QPushButton(tr("🔄 مريض جديد"));
    connect(m_btnNewPatient, &QPushButton::clicked, this, &MainWindow::onNewPatient);
    toolbar->addWidget(m_btnNewPatient);

    toolbar->addSeparator();

    m_btnSelectTests = new QPushButton(tr("☑ اختيار التحاليل"));
    connect(m_btnSelectTests, &QPushButton::clicked, this, &MainWindow::onSelectTests);
    toolbar->addWidget(m_btnSelectTests);

    toolbar->addSeparator();

    m_btnSave = new QPushButton(tr("💾 حفظ"));
    connect(m_btnSave, &QPushButton::clicked, this, &MainWindow::onSaveState);
    toolbar->addWidget(m_btnSave);

    toolbar->addSeparator();

    m_btnPrint = new QPushButton(tr("🖨️ طباعة"));
    connect(m_btnPrint, &QPushButton::clicked, this, &MainWindow::onPrintReport);
    toolbar->addWidget(m_btnPrint);

    toolbar->addSeparator();

    auto *btnExport = new QPushButton(tr("📤 تصدير"));
    connect(btnExport, &QPushButton::clicked, this, &MainWindow::onExportJson);
    toolbar->addWidget(btnExport);
}

// ═══════════════════════════════════════════════════════
//  Style
// ═══════════════════════════════════════════════════════

void MainWindow::applyStyle()
{
    QFile styleFile(QStringLiteral(":/style.qss"));
    if (styleFile.open(QIODevice::ReadOnly)) {
        setStyleSheet(QString::fromUtf8(styleFile.readAll()));
    }
    setLayoutDirection(Qt::RightToLeft);
}

// ═══════════════════════════════════════════════════════
//  Sheet Switching
// ═══════════════════════════════════════════════════════

void MainWindow::onSheetChanged(int index)
{
    auto type = static_cast<SheetType>(qBound(0, index, 3));
    switchSheet(type);
}

void MainWindow::switchSheet(SheetType type)
{
    m_data.currentSheet = type;

    if (isFixedSheet(type)) {
        setAllTestsChecked(true);
    }

    if (type == SheetType::Semen && m_patientGenderCombo) {
        m_patientGenderCombo->setCurrentIndex(0);
    }

    populateTestTable();
    updateReportPreview();
    if (m_db) m_db->savePatient(m_data.patient, m_data.currentSheet, m_data.nextTestId);
    showStatusBarMessage(tr("الورقة: %1").arg(sheetTypeLabel(type)));
}

// ═══════════════════════════════════════════════════════
//  Patient Fields
// ═══════════════════════════════════════════════════════

void MainWindow::onPatientNameChanged(const QString &text)
{
    m_data.patient.name = text;
    if (m_db) m_db->savePatient(m_data.patient, m_data.currentSheet, m_data.nextTestId);
    updateReportPreview();
}

void MainWindow::onPatientDateChanged(const QDate &date)
{
    if (!date.isValid()) return;
    m_data.patient.date = date;
    if (m_db) m_db->savePatient(m_data.patient, m_data.currentSheet, m_data.nextTestId);
    updateReportPreview();
}

void MainWindow::onPatientGenderChanged(int index)
{
    if (index < 0 || index > 2) return;
    m_data.patient.gender = static_cast<Gender>(index);
    if (m_db) m_db->savePatient(m_data.patient, m_data.currentSheet, m_data.nextTestId);
    populateTestTable();
    updateReportPreview();
}

// ═══════════════════════════════════════════════════════
//  Test Table
// ═══════════════════════════════════════════════════════

void MainWindow::populateTestTable()
{
    if (!m_testTable) return;

    m_testTable->blockSignals(true);
    m_testTable->setRowCount(0);

    const auto &tests = m_data.currentSheetData().tests;
    int count = tests.size();
    m_testTable->setRowCount(count);

    for (int i = 0; i < count; ++i) {
        const auto &t = tests[i];

        auto *chkItem = new QTableWidgetItem();
        chkItem->setFlags(Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);
        chkItem->setCheckState(t.checked ? Qt::Checked : Qt::Unchecked);
        chkItem->setData(Qt::UserRole, t.id);
        m_testTable->setItem(i, 0, chkItem);

        auto *nameItem = new QTableWidgetItem(t.name);
        nameItem->setFlags(nameItem->flags() | Qt::ItemIsEditable);
        nameItem->setData(Qt::UserRole, t.category);
        m_testTable->setItem(i, 1, nameItem);

        auto *normalItem = new QTableWidgetItem(t.normalValue(m_data.patient.gender));
        normalItem->setFlags(normalItem->flags() | Qt::ItemIsEditable);
        normalItem->setToolTip(tr("تعديل المجال الطبيعي يحفظ مباشرة في قاعدة البيانات"));
        m_testTable->setItem(i, 2, normalItem);

        auto *unitItem = new QTableWidgetItem(t.unit);
        unitItem->setFlags(unitItem->flags() | Qt::ItemIsEditable);
        m_testTable->setItem(i, 3, unitItem);

        auto *resultItem = new QTableWidgetItem(t.result);
        resultItem->setFlags(Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemIsSelectable);
        m_testTable->setItem(i, 4, resultItem);

        auto *typeItem = new QTableWidgetItem(qualTypeKey(t.qualitativeType));
        typeItem->setFlags(typeItem->flags() & ~Qt::ItemIsEditable);
        m_testTable->setItem(i, 5, typeItem);

        if (!t.category.isEmpty()) {
            QColor catColor(getCategoryColor(t.category));
            for (int c = 0; c < 6; ++c) {
                auto *item = m_testTable->item(i, c);
                if (item) item->setForeground(catColor);
            }
        }
    }

    m_testTable->blockSignals(false);
}

void MainWindow::onTestCellChanged(int row, int col)
{
    if (!m_testTable) return;
    auto &tests = m_data.currentSheetData().tests;
    if (row < 0 || row >= tests.size()) return;
    auto &test = tests[row];
    auto *item = m_testTable->item(row, col);
    if (!item) return;

    bool changed = false;
    if (col == 0) {
        const bool v = (item->checkState() == Qt::Checked);
        changed = (test.checked != v);
        test.checked = v;
    } else if (col == 1) {
        changed = (test.name != item->text());
        test.name = item->text();
    } else if (col == 2) {
        const QString v = item->text();
        switch (m_data.patient.gender) {
        case Gender::Female: changed = (test.normalFemale != v); test.normalFemale = v; break;
        case Gender::Child:  changed = (test.normalChild != v);  test.normalChild = v; break;
        default:             changed = (test.normalMale != v);   test.normalMale = v; break;
        }
    } else if (col == 3) {
        changed = (test.unit != item->text());
        test.unit = item->text();
    } else if (col == 4) {
        changed = (test.result != item->text());
        test.result = item->text();
    }

    if (!changed) return;
    if (m_db && m_db->saveTest(m_data.currentSheet, test))
        showStatusBarMessage(tr("تم الحفظ ✓"), 900);
    else
        showStatusBarMessage(tr("فشل الحفظ"), 2500);

    if (col == 0 || col == 4) updateReportPreview();
    else if (col == 1 || col == 2 || col == 3) updateReportPreview();
}

void MainWindow::setAllTestsChecked(bool checked)
{
    auto &tests = m_data.currentSheetData().tests;
    for (auto &t : tests) t.checked = checked;
    populateTestTable();
    updateReportPreview();
    if (m_db) m_db->saveSheetChecks(m_data.currentSheet, tests);
    showStatusBarMessage(checked ? tr("تم تحديد الكل وحفظه") : tr("تم إلغاء التحديد وحفظه"));
}

// ═══════════════════════════════════════════════════════
//  Report Preview
// ═══════════════════════════════════════════════════════

void MainWindow::updateReportPreview()
{
    if (!m_reportWidget) return;
    QString html = HtmlReportGenerator::generate(m_data);
    m_reportWidget->setHtml(html);
}

// ═══════════════════════════════════════════════════════
//  Print Validation — warn if checked tests have empty results
// ═══════════════════════════════════════════════════════

bool MainWindow::validateBeforePrint()
{
    auto checked = m_data.currentSheetData().checkedTests();
    if (checked.isEmpty()) {
        if (m_sound) m_sound->play(SoundManager::WarningAlert);
        QMessageBox::warning(this, tr("تنبيه"),
            tr("لم يتم اختيار أي تحليل للطباعة."));
        return false;
    }

    // Collect tests with empty results
    QStringList emptyTests;
    for (const auto &t : checked) {
        bool isEmpty = t.result.trimmed().isEmpty();
        // For IgG_IgM type, both fields must be filled
        if (t.qualitativeType == QualType::IgG_IgM) {
            isEmpty = (t.resultIgg.trimmed().isEmpty() || t.resultIgm.trimmed().isEmpty());
        }
        if (isEmpty) {
            emptyTests << t.name;
        }
    }

    if (!emptyTests.isEmpty()) {
        if (m_sound) m_sound->play(SoundManager::WarningAlert);

        QString msg = tr("التحاليل التالية محددة لكن بدون نتيجة:

%1

هل تريد الطباعة بدون هذه النتائج؟")
            .arg(emptyTests.join(QStringLiteral("\n")));

        auto reply = QMessageBox::warning(this, tr("نتائج فارغة"), msg,
            QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
        return (reply == QMessageBox::Yes);
    }

    return true;
}

// ═══════════════════════════════════════════════════════
//  Actions
// ═══════════════════════════════════════════════════════

void MainWindow::onNewPatient()
{

    m_data.patient.name.clear();
    m_data.patient.date = QDate::currentDate();
    m_data.patient.gender = Gender::Male;

    if (m_patientNameEdit)    m_patientNameEdit->clear();
    if (m_patientDateEdit)    m_patientDateEdit->setDate(QDate::currentDate());
    if (m_patientGenderCombo) m_patientGenderCombo->setCurrentIndex(0);

    for (auto &sheet : m_data.sheets) {
        for (auto &t : sheet.tests) {
            t.result.clear();
            t.resultIgg.clear();
            t.resultIgm.clear();
        }
    }

    populateTestTable();
    updateReportPreview();
    if (m_db) m_db->savePatient(m_data.patient, m_data.currentSheet, m_data.nextTestId);
    if (m_db) m_db->replaceAllTests(m_data);
    showStatusBarMessage(tr("مريض جديد — تم الحفظ ✓"));
}

void MainWindow::onSelectTests()
{
    TestSelectionDialog dlg(m_data, this);
    if (dlg.exec() == QDialog::Accepted) {
        populateTestTable();
        updateReportPreview();
        if (m_db) m_db->replaceAllTests(m_data);
        showStatusBarMessage(tr("تم تحديث التحاليل المحددة وحفظها ✓"));
    }
}

void MainWindow::onSaveState()
{
    if (m_db) m_db->saveFullState(m_data);
    showStatusBarMessage(tr("تم الحفظ"));
}

void MainWindow::onExportJson()
{
    QString path = QFileDialog::getSaveFileName(
        this, tr("تصدير البيانات"),
        QStringLiteral("lab_backup_%1.json").arg(
            QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss")),
        tr("JSON Files (*.json);;All Files (*)")
    );
    if (!path.isEmpty() && m_db) {
        if (m_db->exportToJsonFile(path, m_data))
            showStatusBarMessage(tr("تم التصدير: %1").arg(path));
    }
}

void MainWindow::onImportJson()
{
    QString path = QFileDialog::getOpenFileName(
        this, tr("استيراد البيانات"), {},
        tr("JSON Files (*.json);;All Files (*)")
    );
    if (!path.isEmpty() && m_db) {
        auto imported = m_db->importFromJsonFile(path);
        if (imported.sheets.isEmpty()) return;

        if (QMessageBox::question(this, tr("تأكيد"),
                tr("هل تريد استبدال البيانات الحالية؟")) == QMessageBox::Yes) {
            m_data = imported;
            if (m_patientNameEdit)    m_patientNameEdit->setText(m_data.patient.name);
            if (m_patientDateEdit)    m_patientDateEdit->setDate(
                m_data.patient.date.isValid() ? m_data.patient.date : QDate::currentDate());
            if (m_patientGenderCombo) m_patientGenderCombo->setCurrentIndex(
                qBound(0, static_cast<int>(m_data.patient.gender), 2));
            if (m_sheetTabs) m_sheetTabs->setCurrentIndex(
                qBound(0, static_cast<int>(m_data.currentSheet), 3));

            populateTestTable();
            updateReportPreview();
            if (m_db) m_db->replaceAllTests(m_data);
            showStatusBarMessage(tr("تم الاستيراد والحفظ ✓"));
        }
    }
}

void MainWindow::onBackupSqlite()
{
    if (!m_db) return;
    const QString path = QFileDialog::getSaveFileName(this, tr("نسخة احتياطية SQLite"),
        QStringLiteral("LabDesktop_Backup_%1.db").arg(QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss")),
        tr("SQLite Database (*.db)"));
    if (path.isEmpty()) return;
    m_db->saveFullState(m_data);
    if (m_db->backupDatabase(path))
        showStatusBarMessage(tr("تم إنشاء النسخة الاحتياطية ✓"), 3000);
    else
        showStatusBarMessage(tr("فشل إنشاء النسخة الاحتياطية"), 3000);
}

void MainWindow::onRestoreSqlite()
{
    if (!m_db) return;
    const QString path = QFileDialog::getOpenFileName(this, tr("استعادة نسخة SQLite"), {},
        tr("SQLite Database (*.db)"));
    if (path.isEmpty()) return;
    if (QMessageBox::question(this, tr("تأكيد الاستعادة"),
            tr("سيتم استبدال البيانات الحالية بالنسخة الاحتياطية. هل تريد المتابعة؟")) != QMessageBox::Yes)
        return;
    if (!m_db->restoreDatabase(path)) {
        showStatusBarMessage(tr("فشلت الاستعادة"), 3000);
        return;
    }
    m_data = m_db->loadFullState();
    if (m_patientNameEdit) m_patientNameEdit->setText(m_data.patient.name);
    if (m_patientDateEdit) m_patientDateEdit->setDate(m_data.patient.date.isValid() ? m_data.patient.date : QDate::currentDate());
    if (m_patientGenderCombo) m_patientGenderCombo->setCurrentIndex(qBound(0, static_cast<int>(m_data.patient.gender), 2));
    if (m_sheetTabs) m_sheetTabs->setCurrentIndex(qBound(0, static_cast<int>(m_data.currentSheet), 3));
    populateTestTable();
    updateReportPreview();
    showStatusBarMessage(tr("تمت الاستعادة ✓"), 3000);
}

void MainWindow::onPrintReport()
{
    if (!m_reportWidget) {
        showStatusBarMessage(tr("معاينة التقرير غير جاهزة"));
        return;
    }

    // Validate before printing
    if (!validateBeforePrint()) return;

    QPrinter printer(QPrinter::HighResolution);
    printer.setPageOrientation(QPageLayout::Portrait);

    QPrintDialog dlg(&printer, this);
    dlg.setWindowTitle(tr("طباعة التقرير"));
    if (dlg.exec() == QDialog::Accepted) {
        m_reportWidget->print(&printer);
        showStatusBarMessage(tr("جاري الطباعة..."));
    }
}

void MainWindow::onRefreshReport()
{
    updateReportPreview();
    showStatusBarMessage(tr("تم تحديث المعاينة"));
}

// ═══════════════════════════════════════════════════════
//  Auto-save
// ═══════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════
//  Helpers
// ═══════════════════════════════════════════════════════

void MainWindow::loadDefaultTests()
{
    QFile f(QStringLiteral(":/default_tests.json"));
    if (!f.open(QIODevice::ReadOnly)) {
        qWarning() << "Failed to load default tests from embedded resource";
        return;
    }

    QByteArray raw = f.readAll();
    if (raw.isEmpty()) {
        qWarning() << "Default tests resource is empty";
        return;
    }

    QJsonParseError err;
    QJsonDocument doc = QJsonDocument::fromJson(raw, &err);
    if (err.error != QJsonParseError::NoError) {
        qWarning() << "Default tests JSON error:" << err.errorString()
                   << "at offset" << err.offset;
        return;
    }

    if (!doc.isObject()) {
        qWarning() << "Default tests: root is not a JSON object";
        return;
    }

    m_data = AllSheetsData::fromJson(doc.object());
    qDebug() << "Loaded default tests for" << m_data.sheets.size() << "sheets";
}

void MainWindow::showStatusBarMessage(const QString &msg, int ms)
{
    if (!m_statusLabel) return;
    m_statusLabel->setText(msg);
    if (ms > 0)
        QTimer::singleShot(ms, this, [this]() {
            if (m_statusLabel) m_statusLabel->clear();
        });
}

} // namespace Lab
