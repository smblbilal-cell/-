#include "TestSelectionDialog.h"

#include <QHeaderView>
#include <QCheckBox>

namespace Lab {

// ═══════════════════════════════════════════════════════
//  Constructor
// ═══════════════════════════════════════════════════════

TestSelectionDialog::TestSelectionDialog(AllSheetsData &data, QWidget *parent)
    : QDialog(parent)
    , m_data(data)
{
    setWindowTitle(tr("اختيار التحاليل - ") + sheetTypeLabel(m_data.currentSheet));
    setMinimumSize(500, 600);
    resize(550, 700);
    setLayoutDirection(Qt::RightToLeft);

    // ── Search filter ─────────────────────────────
    auto *filterLayout = new QHBoxLayout();
    m_filterEdit = new QLineEdit(this);
    m_filterEdit->setPlaceholderText(tr("🔍 بحث في التحاليل..."));
    connect(m_filterEdit, &QLineEdit::textChanged, this, &TestSelectionDialog::onFilterChanged);
    filterLayout->addWidget(m_filterEdit);

    // ── Tree widget ───────────────────────────────
    m_tree = new QTreeWidget(this);
    m_tree->setHeaderLabels({tr(""), tr("التحليل")});
    if (auto *hdr = m_tree->header()) {
        hdr->setSectionResizeMode(0, QHeaderView::ResizeToContents);
        hdr->setSectionResizeMode(1, QHeaderView::Stretch);
    }
    m_tree->setAlternatingRowColors(true);
    m_tree->setAnimated(true);
    connect(m_tree, &QTreeWidget::itemClicked, this, &TestSelectionDialog::onCategoryClicked);

    // ── Buttons ───────────────────────────────────
    auto *btnLayout = new QHBoxLayout();
    m_btnSelectAll = new QPushButton(tr("☑ تحديد الكل"), this);
    m_btnDeselectAll = new QPushButton(tr("☐ إلغاء الكل"), this);
    connect(m_btnSelectAll, &QPushButton::clicked, this, &TestSelectionDialog::onSelectAll);
    connect(m_btnDeselectAll, &QPushButton::clicked, this, &TestSelectionDialog::onDeselectAll);
    btnLayout->addWidget(m_btnSelectAll);
    btnLayout->addWidget(m_btnDeselectAll);
    btnLayout->addStretch();

    auto *dialogButtons = new QDialogButtonBox(
        QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
    connect(dialogButtons, &QDialogButtonBox::accepted, this, &QDialog::accept);
    connect(dialogButtons, &QDialogButtonBox::rejected, this, &QDialog::reject);
    btnLayout->addWidget(dialogButtons);

    // ── Main layout ───────────────────────────────
    auto *mainLayout = new QVBoxLayout(this);
    mainLayout->addLayout(filterLayout);
    mainLayout->addWidget(m_tree, 1);
    mainLayout->addLayout(btnLayout);

    buildTree();
}

// ═══════════════════════════════════════════════════════
//  Build Category Tree
// ═══════════════════════════════════════════════════════

void TestSelectionDialog::buildTree()
{
    if (!m_tree) return; // Null guard
    m_tree->clear();
    const auto &tests = m_data.currentSheetData().tests;

    // Group by category
    QMap<QString, QVector<int>> catMap;
    for (int i = 0; i < tests.size(); ++i) {
        QString cat = tests[i].category.isEmpty() ? QStringLiteral("Uncategorized") : tests[i].category;
        catMap[cat].append(i);
    }

    const QStringList cats = catMap.keys();
    for (const auto &cat : cats) {
        auto *catItem = new QTreeWidgetItem(m_tree);
        catItem->setText(0, tr(""));
        catItem->setText(1, cat + QStringLiteral("  (") + QString::number(catMap[cat].size()) + tr(")"));
        catItem->setData(0, Qt::UserRole, cat);
        catItem->setExpanded(true);
        catItem->setFont(1, QFont(catItem->font(1).family(), 10, QFont::Bold));

        // Color
        QString color = getCategoryColor(cat);
        catItem->setForeground(1, QColor(color));

        // Count checked
        int checkedCount = 0;
        for (int idx : catMap[cat])
            if (tests[idx].checked) ++checkedCount;
        catItem->setCheckState(0, checkedCount == catMap[cat].size() ? Qt::Checked
                            : checkedCount > 0 ? Qt::PartiallyChecked : Qt::Unchecked);

        // Child items (tests)
        for (int idx : catMap[cat]) {
            auto *testItem = new QTreeWidgetItem(catItem);
            testItem->setText(1, tests[idx].name);
            testItem->setData(0, Qt::UserRole, tests[idx].id);
            testItem->setCheckState(0, tests[idx].checked ? Qt::Checked : Qt::Unchecked);
            catItem->addChild(testItem);
        }
    }
}

// ═══════════════════════════════════════════════════════
//  Category Clicked
// ═══════════════════════════════════════════════════════

void TestSelectionDialog::onCategoryClicked(QTreeWidgetItem *item, int column)
{
    if (!item || !m_tree || column != 0) return;

    Qt::CheckState state = item->checkState(0);

    if (!item->parent()) {
        // Category header → toggle all children
        for (int i = 0; i < item->childCount(); ++i) {
            auto *child = item->child(i);
            if (!child) continue; // Null guard
            child->setCheckState(0, state);
            int testId = child->data(0, Qt::UserRole).toInt();
            for (auto &t : m_data.currentSheetData().tests)
                if (t.id == testId) { t.checked = (state == Qt::Checked); break; }
        }
    } else {
        // Individual test
        int testId = item->data(0, Qt::UserRole).toInt();
        for (auto &t : m_data.currentSheetData().tests)
            if (t.id == testId) { t.checked = (state == Qt::Checked); break; }

        // Update parent check state
        auto *parent = item->parent();
        if (parent) {
            int total = parent->childCount();
            int checked = 0;
            for (int i = 0; i < total; ++i)
                if (parent->child(i)->checkState(0) == Qt::Checked) ++checked;
            parent->setCheckState(0, checked == total ? Qt::Checked
                                : checked > 0 ? Qt::PartiallyChecked : Qt::Unchecked);
        }
    }
}

// ═══════════════════════════════════════════════════════
//  Select / Deselect All
// ═══════════════════════════════════════════════════════

void TestSelectionDialog::onSelectAll()
{
    for (auto &t : m_data.currentSheetData().tests) t.checked = true;
    buildTree();
}

void TestSelectionDialog::onDeselectAll()
{
    for (auto &t : m_data.currentSheetData().tests) t.checked = false;
    buildTree();
}

// ═══════════════════════════════════════════════════════
//  Filter
// ═══════════════════════════════════════════════════════

void TestSelectionDialog::onFilterChanged(const QString &text)
{
    if (!m_tree) return; // Null guard
    m_currentFilter = text.toLower();
    for (int i = 0; i < m_tree->topLevelItemCount(); ++i) {
        auto *catItem = m_tree->topLevelItem(i);
        if (!catItem) continue; // Null guard
        bool catVisible = false;
        for (int j = 0; j < catItem->childCount(); ++j) {
            auto *testItem = catItem->child(j);
            if (!testItem) continue; // Null guard
            bool match = m_currentFilter.isEmpty()
                || testItem->text(1).toLower().contains(m_currentFilter);
            testItem->setHidden(!match);
            if (match) catVisible = true;
        }
        catItem->setHidden(!catVisible);
    }
}

} // namespace Lab